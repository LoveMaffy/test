# Citrix Gateway + Keycloak SAML 部署文档

## 一、环境信息

| 角色 | 地址 | 说明 |
|---|---|---|
| Citrix ADC 管理 | 192.168.190.30 | ssh nsroot / P@ssw0rd，登录后输入 `shell` 才是 bash |
| Citrix Gateway (VPN vserver) | https://192.168.190.31/ | vserver 名 `nsvpx` |
| Citrix 认证 vserver | 192.168.190.32:443 | vserver 名 `av-saml` |
| Keycloak (IdP, 本机 Kali) | http://192.168.190.131:8080 | 版本 26.7.2，`start-dev` 模式，H2 数据库 |
| 测试机 | 192.168.190.131 | Kali + chromium + selenium |

**账号：**
- Keycloak 管理员：`admin / admin`（dev 临时管理员，master realm）
- 测试用户（citrix realm）：`samluser / Samlpass123`

**认证链路：**
```
浏览器 -> https://192.168.190.31/ (GW nsvpx)
   └─ authnProfile kc-profile -> 认证vserver av-saml (192.168.190.32)
        └─ 高级认证策略 kc-saml-pol (优先级100)
             └─ samlAction kc-saml -> POST SAMLRequest
                  -> http://192.168.190.131:8080/realms/citrix/protocol/saml (Keycloak)
                  <- POST SAMLResponse -> https://192.168.190.31/cgi/samlauth (ACS)
```

## 二、Keycloak 侧部署（Kali 本机）

### 1. 安装与启动
```bash
cd /home/kali/Desktop/citrix_
unzip keycloak-26.7.2.zip
cd keycloak-26.7.2
# 注意必须加 --http-host=0.0.0.0，否则只监听 localhost，Citrix 访问不到
nohup bin/kc.sh start-dev --http-host=0.0.0.0 --http-port=8080 > ../keycloak.log 2>&1 &
```

### 2. 创建 Realm 和用户
管理台 http://192.168.190.131:8080 （admin/admin）：
1. Create Realm，名称 `citrix`
2. Users -> Create user：`samluser`，密码 `Samlpass123`（Temporary 关掉）

### 3. 创建 SAML 客户端（关键配置）
Clients -> Create client：
- Client type: `SAML`，Client ID: `citrix-gw`（必须与 Citrix samlAction 的 samlIssuerName 完全一致）
- Valid redirect URLs / Master SAML Processing URL: `https://192.168.190.31/cgi/samlauth`

创建后在 Settings 里：
- **Client signature required: OFF**（Citrix 的 samlAction 未配 SigningCert，AuthnRequest 不签名；开着此项会报 `invalid_signature` —— 本次部署踩过的坑）
- **Sign documents / assertions: ON**（Keycloak 对 SAMLResponse 签名，配合 Citrix 的 Reject unsigned assertion ON）
- Signature algorithm: `RSA_SHA256`
- Force POST binding（authnrequest/response/logout 均 POST）
- Name ID format: `username`

命令行等价操作（kcadm）：
```bash
cd keycloak-26.7.2/bin
./kcadm.sh config credentials --server http://127.0.0.1:8080 --realm master --user admin --password admin
CID=$(./kcadm.sh get clients -r citrix | python3 -c "import sys,json;print([c['id'] for c in json.load(sys.stdin) if c['clientId']=='citrix-gw'][0])")
./kcadm.sh update clients/$CID -r citrix -s 'attributes={"saml.client.signature":"false", ...}'
```

### 4. 导出 IdP 签名证书（给 Citrix 用）
```bash
curl -s http://192.168.190.131:8080/realms/citrix/protocol/saml/descriptor \
  | python3 -c "import sys,re,base64; c=re.search(r'<ds:X509Certificate>([^<]+)',sys.stdin.read()).group(1); \
import textwrap; print('\n'.join(['-----BEGIN CERTIFICATE-----']+textwrap.wrap(c,64)+['-----END CERTIFICATE-----']))" \
  > kc-realm-cert.pem
```
（即现有的 `kc-realm-cert.pem`，CN=citrix，Keycloak realm 签名密钥的证书）

## 三、Citrix 侧部署（ssh nsroot@192.168.190.30）

### 1. 上传 IdP 证书并创建 certKey
把 `kc-realm-cert.pem` 放到 `/nsconfig/ssl/`（scp 到管理口后 shell 里 cp），然后：
```
add ssl certKey kc-idp-cert -cert kc-realm-cert.pem
```
（只有公钥证书，无 -key，用于验证 Keycloak 的签名）

### 2. 创建 samlAction（SP 配置）
```
add authentication samlAction kc-saml \
  -samlIdPCertName kc-idp-cert \
  -samlRedirectUrl "http://192.168.190.131:8080/realms/citrix/protocol/saml" \
  -samlIssuerName citrix-gw \
  -samlAudience citrix-gw \
  -samlUserField username \
  -samlBinding POST \
  -signatureAlg RSA-SHA256 \
  -digestMethod SHA256 \
  -samlRejectUnsignedAssertion ON \
  -skewTime 5
```
要点：
- `samlIssuerName` = `samlAudience` = Keycloak 的 Client ID（`citrix-gw`）
- 未配置 `signingCert`（SP 不签 AuthnRequest），所以 Keycloak 侧必须关 Client signature required
- `samlUserField username`：从 Keycloak 返回的 assertion Subject(NameID) 取用户名

### 3. 创建认证策略、认证 vserver、authnProfile 并挂到 GW
```
add authentication policy kc-saml-pol -rule "true" -action kc-saml
add authentication vserver av-saml SSL 192.168.190.32 443
bind ssl vserver av-saml -certkeyName ns-server-certificate
bind authentication vserver av-saml -policy kc-saml-pol -priority 100 -gotoPriorityExpression NEXT
add authentication authnProfile kc-profile -authnVsname av-saml
set vpn vserver nsvpx -authnProfile kc-profile
save ns config
```

## 四、验证方法

1. **手工验证**：浏览器打开 https://192.168.190.31/ ，应自动跳转到 Keycloak 登录页，
   用 `samluser / Samlpass123` 登录后回到 GW 门户。
2. **curl 快速验证 SP->IdP 段**：
   ```bash
   curl -sk -c /tmp/cj -b /tmp/cj -X POST https://192.168.190.31/cgi/login \
     --data-urlencode "username=test" --data-urlencode "password=test" -o /tmp/s.html
   # 解出页面里的 SAMLRequest (base64) 再 POST 给 Keycloak，应 302 到 login-actions 登录页
   ```
3. **自动化**：`python3 saml_test.py`（selenium + chromium 无头浏览器全流程）

## 五、故障排查记录

### 踩坑 1：invalid_signature（已解决）
- 现象：Keycloak 日志 `request validation failed: Invalid signature on document`
- 根因：Citrix samlAction 无 SigningCert，AuthnRequest 不签名；Keycloak 客户端却开着
  "Client signature required"
- 修复：Keycloak 客户端 `citrix-gw` 的 `saml.client.signature` 置 false
- 验证：重放 SAMLRequest，Keycloak 正常 302 到登录表单

### 踩坑 2：Keycloak 重启后 Citrix 连不上（已解决）
- 现象：`start-dev` 默认只绑 `localhost:8080`（首次安装时是 0.0.0.0，重启后变 localhost）
- 修复：启动加 `--http-host=0.0.0.0`

### 待解决：selenium 端到端测试最后一步
- `saml_test.py` 运行到 Keycloak 登录页后未找到 `#username` 元素超时；
  Keycloak 日志同时出现一条 `user_not_found, username=admin` 的登录尝试（来源待查，
  疑似浏览器自动填充或残留会话）
- curl 手工验证 SP->IdP 段已通，说明 SAML 协议层正常，是测试脚本/浏览器层面的问题
- 下一步：截图排查 Keycloak 登录页实际渲染情况，改用显式等待 + 排查 chromium autofill

## 六、CVE-2026-19490 漏洞排查（2026-08-20）

Rapid7 于 2026-08-19 发布公告：CVE-2026-19490，Citrix NetScaler ADC/Gateway
**未认证远程认证绕过**（authentication bypass），CVSS v4.0 = 9.3，无需用户交互。

**本实验室设备核查结果：存在漏洞（likely exploitable）**
- 设备版本：`NS14.1 Build 66.54.nc`（2026-02-24）—— 在受影响范围
  （14.1 < 73.32 / 13.1 < 63.21）
- 触发配置条件（Citrix 官方判据）三条全部命中：
  1. `add authentication samlAction kc-saml` ✅（本次 SAML 部署所加）
  2. `add authentication vserver av-saml` ✅
  3. `add vpn vserver nsvpx` ✅
- 即：我们搭的这套 SAML 环境正好满足该漏洞的利用条件

**公开信息情况（2026-08-20 查证）：**
- 官方公告：CTX696939（support.citrix.com），NVD 已收录
- GitHub 上暂无公开 PoC（搜索 CVE-2026-19490 / netscaler saml bypass 均为 0）
- Rapid7：暂无在野利用证据

**修复方案：** 升级到 14.1-73.32+ 或 13.1-63.21+。
实验室环境（192.168.190.x 内网隔离）可保留该版本用于漏洞复现研究，
但切勿将该版本暴露到公网。

> 注：2026-08-20 会话结束时 Keycloak 后台进程被终止，SAML 联调如需继续，
> 重启命令：`cd /home/kali/Desktop/citrix_/keycloak-26.7.2 && nohup bin/kc.sh start-dev --http-host=0.0.0.0 --http-port=8080 > ../keycloak.log 2>&1 &`

## 七、进度日志
- [2026-08-20 09:04] Keycloak 解压并首次启动 (dev 模式, 8080)
- [2026-08-20 09:03-09:16] 建 realm `citrix`、用户 samluser、SAML 客户端 citrix-gw；
  导出证书 gw-cert/kc-realm-cert；Citrix 侧建好 samlAction/av-saml/kc-profile 并挂到 nsvpx
- [2026-08-20 09:11-09:16] 首次联调：Keycloak 报 `invalid_signature`（坑1）
- [2026-08-20 09:23] 上次会话结束，Keycloak 停止
- [2026-08-20 09:25] 本次会话：重启 Keycloak，发现绑定 localhost 问题（坑2），加 --http-host 修复
- [2026-08-20 09:27] 定位坑1 根因（AuthnRequest 实际未签名），关闭 Keycloak 客户端签名校验，
  重放 SAMLRequest 验证通过
- [2026-08-20 09:30] 跑 saml_test.py：SP->IdP 跳转已通，卡在 Keycloak 登录页元素定位（见"待解决"）
- [2026-08-20 09:35] Citrix 侧 `save ns config`（之前 saml 配置只在内存，已固化到 /nsconfig/ns.conf）
- [2026-08-20 09:36] 整理本部署文档
- [2026-08-20 CVE 排查] 核查 CVE-2026-19490：本设备 14.1-66.54 受影响且满足
  全部利用条件（详见第六节）；GitHub 暂无公开 PoC
- [2026-08-22 artifact 通道测试] 切换 samlAction 到 Artifact binding，补齐 KC artifact
  配置（ACS=/cgi/samlart、resolve 端点）、给 NS 加 190.40 SNIP（PPE 后端连接
  原来 source 自 187.x 不可达子网导致 "Couldnt create connection"）、本机 443 起
  TLS 代理（cdnfly 已停）后 artifact 流程全线打通。
  **MITM 位决定性实验**（假 resolve 服务器三种模式）：
  - proxy（透传真 Keycloak 响应）-> 会话签发（基线成立）
  - strip_sig（去签名）-> 拒绝 0xe0005
  - change_user（保留签名改 NameID）-> 拒绝 0xe0007 "digest verification failed"
  结论：**artifact 后通道对签名+摘要有完整校验**，此线索排除。
  技巧记录：改 artifactResolutionServiceURL 后 PPE 缓存后端 server 对象，
  需要来回切换 URL 强制重新解析；NS 的 ArtifactResolve 请求本身用 SP 证书签名。
- [2026-08-22 最终测试矩阵] AAA vserver(.32) 直投/GET 提交/deflate 提交/
  无签名/篡改/重放全部被正确拒绝（重放有 "Assertion replay detected" 告警）。
  有效签名响应可在无 pending request 的 vserver 上被接受（IdP-initiated SSO 特性，
  首次使用有效，重放被挡）。
- [2026-08-22 HOK + Deflate 决战测试] **两个剩余面全部排除**。
  前置突破：从 Keycloak H2 数据库提取出 **realm 签名私钥**（`kc-realm-priv.pem`，
  /tmp/kc_copy.mv.db 中 MIIE 开头 base64 与 realm 证书模数匹配），并搭建
  `saml_signer.py` 签名工具（exc-c14n + enveloped + RSA-SHA256，自测通过，
  设备侧通过签名验证——首测卡在受众检查，补 `<saml:Audience>citrix-gw` 后
  基线全通）。从此可构造**任意结构+有效签名**的断言。

  **HOK 测试**（SubjectConfirmation Method=holder-of-key，攻击者用户名）：
  | 变体 | 结果 |
  |---|---|
  | 空 KeyInfo + 有效签名 | **会话签发**（HOK 检查未触发——标志位只在 SCD 含真实证书数据时置位） |
  | 无签名 | 拒（unsigned 门） |
  | 签名损坏 | 拒（verification failed） |
  | KeyInfo 带假证书 + 有效签名 | 拒（"SSL certificate information does not match"——HOK 证书比对生效，无客户端证书即失败） |
  | bearer 无签名（对照） | 拒 |
  结论：**HOK 路径签名强制**，无客户端证书时带证书 KeyInfo 反而更严。
  空 KeyInfo 通过是规范层面弱点但仍需有效 IdP 签名 => 不可利用。**排除**。

  **Deflate 测试**：
  - POST 体（zlib/gzip/双成员拼接/尾随垃圾）：一律 "Malformed"——SP 不自动
    解压 POST 体。**排除**。
  - REDIRECT binding GET（/cgi/samlauth?SAMLResponse=deflate...）：
  设备日志 "Redirect Binding: response or relaystate or sigalg missing" ->
  "Unsigned Assertion seen, denying as per action kc-saml"——GET 方式强制要求
  URL 级 SigAlg+Signature 签名。未提供即拒。**排除**（带合法 URL 签名的
  双成员 deflate 是唯一未跑的子分支，价值边际）。

  **最终判定**：14.1-66.54 上所有可达路径的签名验证均稳固。CVE-2026-19490
  的触发点不在：POST/Redirect/Artifact 三种绑定的响应验证、EncryptedAssertion、
  HOK、deflate、KeyInfo、算法、重放、元数据端点。结合公告版本矩阵
  （14.1-43.55 前/13.1-61.27 前无需 SAML 即受影响），真实缺陷大概率在：
  1) 那批旧版本的**通用 AAA 认证路径**（非 SAML），SAML-gated 变体只是同一
     重构后的残留面；2) 或状态机/竞态类缺陷（异步 canon 回调、pcb 0x20 位），
  需要 14.1-73.32 修复版做二进制 diff 才能定位。
  实验资产：`kc-realm-priv.pem` + `saml_signer.py`（任意有效签名断言）、
  `fake_resolve2.py`（artifact MITM 位）、`poc_hok_decisive.py`、
  `poc_deflate_rb.py`、NS 已加 SNIP 190.40、443 端口现为假 resolve 服务器
  （cdnfly 已停）。
- [2026-08-22 二进制 diff 决战] 拿到修复版 **14.1-73.33** 反编译导出，与 66.54 做全量比对：
  - **ctx 处理器（ns_nfactor_start_saml_auth, 0x10f8a00↔0x118b700）**：C-to-C diff
    仅日志宏换名（sub_11F0560→sub_12958A0），**无语义变化**
  - **process_data（0x9d75f0↔0xa140f0）**：归一化汇编 diff 全部为寄存器重分配
    （r14→r13 等）和异步上下文 ID 重编号（445h→442h 类），**无逻辑变化**
  - **NameIdentifier "incorrect context" 守卫**：字符串 diff 曾误报为新增——实际
    66.54 已存在同样守卫（9F4C59），**非修复点**
  - **唯一实质变化：parse_assertion（0x9f47f0↔0xa44840）的 EncryptedAssertion
    路径重构**——修复版为 enc 断言解析分配全新子上下文
    （sub_A0FB90/0x628 字节 + 置位标志 + 从子解析结果复制 0x50+ 字节到
    ctx+0x5A8），并新增日志 "after parsing enc assertion, start is: "
  - 基于该线索的最后尝试（外层 Signature 标志位污染内层重解析，poc_enc_flag.py
    四变体）：内层重解析使用**全新标志**，全部被拒（917509）
  - 追加验证 SignatureValue 缺失绕过假说（13.1 代码误读）：实机拒绝，
    "absent" 分支实际返回错误而非成功
  **最终判定**：修复集中在 EncryptedAssertion 解析状态重构，与我实锤的
  "case 3 跳过 unsigned 门" 相互印证——漏洞是 enc 路径的状态机缺陷（外层
  处理设置的 pcb 状态影响内层重解析判定），但触发需要特定的两段式报文序列
  （首包进入 case 2 设置 pcb 0x20 位后中断 canon 往返，次包在同会话上复用
  该状态），未能在合理时间内构造成功。完整利用链留待后续。
- [2026-08-22 状态机假说实验] 用 `nsconmsg -g saml -d statswt0` 打开计数器
  通道（41 verify_success/30 reject_unsigned/16 digest_fail/9 decrypt_success
  等全量可见）。两段式攻击实测（poc_desync.py）：
  - A: 损坏签名的 Response-signed 首包(进 canon 路径失败) + 同会话 EncAssertion
    次包 -> 次包仍走内层重解析 unsigned 门拒绝(917509)
  - B: 有效签名首包(成功建会话) + 同会话 enc 次包 -> 同上拒绝
  - C: 单独 enc 对照 -> 拒绝
  - POST SAMLResponse 到 /cgi/samlart（artifact 端点两个 process_data 调用点
    的假说）-> "Query parameter absent"，该端点只认 GET SAMLart 参数，
    未到达处理链
  结论：pcb 残留状态不跨请求污染内层重解析标志。EncAssertion 内层判定
  使用独立标志位，与 diff 所示修复（子上下文隔离）的防御方向一致但
  攻击窗口比预想更窄--需要首包恰好停在 canon 异步往返中途且次包
  复用同一 pcb，时序窗口在同步 HTTP 请求下难以命中。
- [2026-08-23 攻击者视角修正] 用户指出 RC4 密钥提取路线违背攻击者模型
  （CVSS: PR:N/AC:L/AT:N/UI:N = 单条简单请求、无密钥无受害者）。
  重新聚焦纯未认证远程路径。本轮发现与测试：
  **路径枚举**（全变体新鲜断言）：
  - /cgi/samlauth 大小写/路径变体（SamlAuth、//cgi/、/./、/.）全部路由到
    同一处理器且正常验证
  - **无会话主动推送（unsolicited）响应被接受**（无 cookie、无 InResponseTo、
    新会话直接 POST = IdP-initiated SSO 合法行为）；未签名/篡改签名
    在该路径仍被拒（verify_fail 计数器 +1 实证）
  - **/adfs/ls/、/wsfed/passive、/adfs/service/trust/2005/usernamemixed**
    （ADFS 风格路径，0x5ca920 匹配器）POST wa/wresult/wctx 会进入 SAML
    断言处理机器（错误信息"Matching policy not found"= 917517、
    "Parsing of presented Assertion failed"= 917512）--最终卡在
    nFactor DHT 上下文查找（NS_ASYNC_CTX_AAA_SAML_NF_GET_SESSION），
    无合法 ctx 上下文时拒绝。nf=/wv=1 前缀变体无法解锁。
  **nFactor REST API**（/nf/auth/*）：
  - getAuthenticationRequirements.do / doAuthentication.do 无认证返回
    doSaml 重定向（ctx_hint blob + ;wv=0 URL 后缀）
  - `;wv=1` 是路由参数而非模式开关（404）
  - webview/done 端点 = "Invalid webview parameters"/"resume forms: could
    not find valid context" --需要合法 nFactor 上下文
  **EncryptedAssertion 上下文合并差异（二进制 diff 修正）**：
  - "after parsing enc assertion" 代码在漏洞版已存在（此前字符串 diff 误报）
  - 真实差异：漏洞版 9F975C 把解密子解析结果**合并进外层上下文**
    （`mov [r12],1` + 0x60 字节拷到 +5A8）；修复版 A490B4 分配**全新
    0x628 子上下文**再解析再拷贝
  - 合并污染矩阵（外层 dummy Signature 前后/内层尾部垃圾/截断/内层
    签名/嵌套双层加密，poc_enc_merge.py 8 变体）：全部被拒。
    外层签名+无签名内层（poc_signed_outer.py）也被拒（内层独立验签）
  - m_inner_afts_sig 触发 500（内部错误）但无会话
  **版本矩阵再解读**：13.1-61.28+ 仅需"配置了 SAML action"（无需 vserver
  绑定）→ 漏洞在 samlAction 的查找/绑定层（/adfs/ls/ 的 DHT 策略查找
  正是此层）；14.1-43.55 前无需 SAML → 存在非 SAML 的通用 AAA 路径变体。
- [2026-08-23 samlIdP 配置解锁 + ADFS 通道深挖] 补配 IdP 侧配置解锁 WSFed 通道：
  ```
  add authentication samlIdPProfile idp-prof -samlIdPCertName gw-cert
    -samlSPCertName gw-cert -samlIssuerName "https://192.168.190.31/idp"
    -assertionConsumerServiceURL "https://192.168.190.31/adfs/ls/" -audience citrix-gw
  add authentication samlIdPPolicy idp-pol -rule true -action idp-prof
  bind authentication vserver av-saml -policy idp-pol -priority 200
  bind vpn vserver nsvpx -policy idp-pol -priority 200   # GW vserver 也绑
  add aaa user testu1 -password Testpass123!             # 本地用户
  add authentication Policy local-adv -rule true -action LOCAL
  bind authentication vserver av-saml -policy local-adv -priority 300
  ```
  **/adfs/service/trust/2005/usernamemixed**（ADFS 主动登录端点）：
  - SOAP 凭据解析**完全成功**：日志 `WSFed: username (testu1), password (12)
    or message id (urn:uuid:...)` --三个字段全部提取（需前缀-less 标签
    `<Username>/<Password>/<MessageID>`，前缀版只解析出 Username）
  - 凭据进入 aaainfo（用户名@+72/密码@+1660/msgid@+200 全部填充）并调用
    sub_4E65A0（登录分发）--但 AAAD 从未被调用，返回 500 (43524)
  - 会话 cookie/会话预热/SOAPAction/realm/AppliesTo 变体均无法推进
  - 卡点：登录分发需要的 pcb/会话状态未明确（NS_ASYNC_CTX_SAMLIDP_
    ACTIVE_LOGIN 上下文）
  **/adfs/ls/ GET**（被动 sign-in）：`wa=wsignin1.0&wtrealm=...&wctx=...`
  解析成功（日志 `request_id: , wa: wsignin1.0, wctx: abc`），302 到登录页
  --正常启动认证，非绕过
  **/nf/auth/samlidp/postassertion**：500（需完整 IdP 中继上下文）
  **usernamemixed 错误分类学**：字段缺失 = 917509 "unexpected"；
  解析成功后登录分发失败 = HTTP 43524 内部错误
- [2026-08-24 usernamemixed 深挖（时盒收官）] SOAP 凭据解析链完整打通但登录分发受阻：
  - 格式破译：凭据标签必须**前缀-less**（`<Username>/<Password>/<MessageID>`），
    带命名空间前缀只解析出 Username；标签匹配器是手写字节扫描（'user'/'pass'/
    'mess' 三路 dispatch，大小写不敏感）
  - 凭据进入 aaainfo（用户名/密码/messageid 全字段填充）后调用 sub_4E65A0
    登录分发，但 **AAAD 从未被调用**，返回 500 (43524=0xAA04)
  - 排除项：会话预热（NSC_TASS）/SOAPAction/realm/AppliesTo/查询参数/
    本地用户优先级/双 vserver 绑定 --全部不变
  - 结论：usernamemixed 是 **ADFS Proxy/FAS** 专用通道（需 Citrix Receiver
    客户端上下文），纯 SOAP 无法独立完成登录分发。0xAA04 错误在 URL 分发器
    (0x5799f0) jumptable cases 2-4 设置
  - **日志链发现**：/adfs/ls/ sign-in 触发 `do saml endpoint: Bitarray value
    before mask is [1] / Bitmask value received is [2]` -> ctx 序列化 ->
    SAML nFactor 反序列化（`action name copied to samlaction is [kc-saml]`）。
    WSFed sign-in 与 SAML nFactor ctx 链路已联动
  - 修复方向剩余疑点：4E66E3 的 aaainfo+0x30C bit2 检查（=登录类型 2 时
    由 0x5ed280 设置）可能是 usernamemixed 需要的 gate
- [2026-08-24 回顾综合分析（结合全部线索再搜索）] 关键代码新发现 + 跨流移植实验：
  **Bitarray/Bitmask 逻辑破译（4FA949-4FA9F5, sub_4E65A0 内）**：
  - `[r15+2Ch]`（完成因子位图）`&= [r15+18h]>>1`（位掩码）后调用
    **sub_10F8770 = ctx 序列化器** --WSFed/SAML nFactor 状态在此打包进 blob
  - 4FAA62: `or [r15+30Ch], 2`（OTP 注册路径设置 0x30C bit1）
  - 结论：0x30C bit2 是登录类型 gate（0x5ed280 在 type==2 时设置），
    usernamemixed 缺此 gate
  **跨流 ctx blob 移植实验**（WSFed 生成的 ctx 喂给 SAML 回调）：
  - WSFed sign-in ctx blob + Keycloak 合法响应（samluser）→ 会话建立为
    **samluser**（SAML 签名用户胜出，ctx 不覆盖身份）--无身份劫持
  **双因子 ctx 移植实验**（local 优先 + doAuth 提交 testu1 凭据）：
  - 正确密码与**错误密码**都能走完整个流并建立会话！
  - 但日志揭示真相：`AAAD API: sending login req for <>`（空用户名）--
    doAuth 的 answer JSON 凭据键（username/password）与 nFactor 要求的
    凭据 ID（实际渲染的是 nsg-x1-logon-button）不匹配 → 空凭据提交 →
    local 因子级联失败（正常策略级联）→ SAML 因子完成认证
  - 会话身份 = SAML 签名用户（samluser），非 ctx 中的 testu1
  - **非绕过**：策略级联的正常行为，SAML 仍是唯一真实认证因子
  本轮总结：ctx blob 在所有跨流方向上都不覆盖 SAML 签名身份；bitarray
  逻辑是因子完成度跟踪而非权限标志。结合全部证据，CVE 的"备用路径"仍
  最可能在（a）enc-assertion 解析状态残留（需 canon 异步中断配合）或
  （b）旧版本通用 AAA 路径（需 13.1-48.47 深挖）。
- [2026-08-24 enc-assertion/pcb 状态残留决战（方向①收官）]
  **case-2 验证跳过路径完整破译（process_data 9DA82D-9DA90C）**：
  ```
  9DA84E: pcb_info+0x14 |= 0x20        ; canon-pending 置位
  9DA8E6: test pcb+0x60, bit1          ; 连接级认证标记!
  9DA8F1: pcb+0x58 & 0x10200 == 0x10000 ; 连接状态 = 已处理/无pending
  9DA905: 满足两者 → 跳过 canon PDU 发送 → 跳过全部验证 → 清理返回
  ```
  这就是 CWE-288 "备用路径"的字面实现：**SAML 处理信任另一个模块设置的
  连接级认证标记**（pcb+0x60 bit1），标记存在时完全跳过签名验证。
  **位来源追踪**：pcb+0x60 bit1 在整个二进制中只有 TEST 没有 WRITE
  （13 处全是 test）→ 由 PE/proxy/cluster 基础设施层设置（连接被其他
  模块预认证/集群转向时标记），单核 VPX 上 HTTP 层不可达。
  **攻击面测试矩阵**（全部被拒）：
  | 预认证尝试 | 结果 |
  |---|---|
  | 合法 SAML 登录后同会话发 unsigned/dummySig | 验证照常执行（标志不跨请求）|
  | 表单登录（本地凭据）后发 unsigned | 表单登录本身未认证成功 |
  | tmlogin 预认证后发 dummySig | 拒 |
  | EPA 端点（/cgi/epa 等 6 个）预扫描后发 dummySig | 全拒 |
  **canon 完成处理器破译（sub_9EDAA0）**：设置 pcb_info+0x10 |= 0x2000
  （与 pcb+0x58 是不同结构），验证 +0x58/0x60 是连接级（非会话级）。
  **结论**：方向①在单核 VPX 实验环境下不可触发--需要多核/集群部署中
  连接被 PE 转向时残留的认证标记（生产集群环境可能可达）。
  剩余唯一方向：13.1-48.47 的无 SAML 通用 AAA 路径（14.1-43.55 前
  版本的原始漏洞形态）。
- [2026-08-24 "为什么无法复现"深度复盘] **三层原因，其中一层是根本性的**：

  **① 我可能从头就找错了目标（根本原因）**
  版本矩阵的真正含义：
  - 14.1-43.55 前：**任意 Gateway/AAA vserver 可触发（无需 SAML）**
    = 原始漏洞，存在于通用 AAA 认证路径中
  - 14.1-43.56 起：**新增了需要 SAML action 的变体**
    = 43.56 引入的 SAML 代码路径上的第二个实例
  - 两个变体都在 73.32 修复
  **我的全部搜索都集中在 SAML 路径上**（因为实验室配置了 SAML，且我
  假设 SAML-gated 变体就是 THE bug）。但原始漏洞（无 SAML 的那个）
  在通用 AAA 认证代码里——我从没搜过那条路。13.1-61.28+ "仅需
  SAML action（无需 vserver）"进一步暗示漏洞在 action 查找/绑定层。

  **② 之前的 skip 路径解读是错的（已纠正）**
  case-2 的 pcb+0x60/+0x58 skip 路径：
  - 9DA85B: `mov r14, [var_168]`（解析结构体指针）
  - skip 跳到 9D8988 → 返回 r14d = 指针低32位 ≠ 0
  - 调用方 `if (v15)` → 非零 = **失败** → 拒绝
  - **结论：skip 是 fail-closed（连接状态异常时拒绝），不是绕过**
  - 我此前把它解读为绕过是错误的

  **③ 二进制 diff 的噪声问题**
  - 66.54 → 73.33 跨越至少 7 个大版本（67.x~73.x）
  - 数百个函数变更，我用字符串签名只匹配了 7000 对函数
  - EncryptedAssertion 子上下文分配变化可能是重构而非修复
  - 真正的修复可能在（a）nsmgr 等未导出的模块（b）我未比对的函数对中
  - "callers: none" 表明调用图不完整，很多函数通过函数指针调用

  **④ 实验室环境限制**
  - 单核 VPX（无集群 PE 转向场景）
  - 无客户端证书认证配置
  - 无生产级 nFactor 多因子链
  - 无 OAuth/OIDC action
  - Keycloak 是唯一 IdP（无 ADFS/Okta 行为差异测试）

  **正确的下一步**：在 13.1-48.47 导出上搜索**非 SAML 的通用认证路径**
  （表单登录处理、会话建立、tmlogin、证书认证），因为：
  - 13.1-61.27 及更早 = 只需 Gateway/AAA vserver（无 SAML）
  - 该变体在所有受影响版本中都存在
  - 我们手里的 13.1-48.47 导出正好是"无 SAML 触发"组
- [2026-08-23 战况总结] CVE-2026-19490 完整利用链未复现。已实锤：case-3 unsigned 门跳过 +
  SP 公钥可完成解密链（构成漏洞的两个必要构件），但内层重解析的
  独立校验在所有测试组合下仍然生效。修复版差异指向 enc 解析子上下文
  隔离，暗示真实触发依赖特定 pcb 状态残留序列。
- [2026-08-22 黑盒穷尽总结] 全攻击面测试矩阵：
  | 攻击面 | 结果 |
  |---|---|
  | POST 响应签名验证(Response/Assertion两种布局+全部XSW变体) | 稳固 |
  | EncryptedAssertion(公钥加密,IV+PKCS7正确构造) | 解密链通但重解析仍验签 |
  | Artifact 后通道(MITM位,三种篡改模式) | 签名+摘要完整校验(0xe0005/0xe0007) |
  | KeyInfo 替换/删除 | 忽略,用配置证书(安全) |
  | 算法降级(SHA1) | 仅记日志但仍用传入算法完整验证 |
  | 重放(GW/AAA两路径) | 均被检测 |
  | ctx blob 伪造 | 不可能(RC4密钥每次启动随机) |
  | ctx blob 重放 | **被接受**(未认证反序列化,session绑定跳过)但仅恢复"待SAML因子"状态 |
  | 元数据端点/GET提交/AAA直投 | 无懈可击 |
  真实发现(次要): ctx blob 未认证重放、case-3 分类跳过 unsigned 门、
  重放检测按 session-id 键控且错误路径 fail-open(13.1 静态)。
  结合公告版本矩阵: 14.1-43.55 前/13.1-61.27 前无需 SAML 配置即受影响 ->
  那批版本的漏洞在**通用 AAA 认证路径**(非 SAML),14.1-66.54 上的 SAML-gated
  变体可能涉及 HOK 验证或 deflate 变体处理(未测完)。
  静态对抗验证(工作流 12 假设)全部否定单一函数级解释,倾向于状态机/竞态类缺陷,
  需补丁版本(14.1-73.32)二进制做 diff 才能定位。
  - 黑盒阶段：`saml_capture.py`（requests 全流程拿合法签名响应）+
    `saml_mutate.py`（变异测试引擎，30 种攻击变体，成功判定=302+NSC_AAAC）
  - 黑盒结论：两种签名布局（Response 签名 / Assertion-only）下，经典 XSW(8种)、
    篡改、无签名、时间戳/受众/Status/InResponseTo 篡改全部被拒；
    KeyInfo 被忽略（用配置证书验证，安全）。漏洞藏在更深处。
  - 错误分类学：Malformed Assertion(结构) / verification failed(签名+InResponseTo)
    / status not Success / SAML authority error
  - **静态分析**：nsppe 13.1-48.47 反编译导出（665MB，49k 函数），定位 SAML 函数群。
    可疑线索：`ns_saml_sign_verify_new/old` 切换 `ns_aaa_saml_sign_newway`
    （新旧两套签名验证路径）、一批 samlparameter 开关（disable_time_check 等）
  - 多 agent 工作流已启动：管线追踪 -> 6 路深挖 -> 对抗验证
- [2026-08-27 决定性 diff：72.61↔73.33 跨修复边界最小噪声比对] 新增导出
  **14.1-72.61**（仍受影响，距修复仅一步）+ bindiff.txt（BinDiff 导出，38,018 行：
  37,873 对匹配中 **37,271 对完全相同**，~600 变更 + 12 删除 + 128 新增）。
  **重要更正**：`nsppe_14.1-77.33_export_for_ai` 目录名有误，其二进制实为
  **14.1-73.33**（bindiff 段头自标注 + 锚点地址一致）。
  **方法论突破**：旧 66.54↔73.33 diff 跨 7 个大版本噪声数百函数；72.61↔73.33
  只跨修复线 73.32，变更集极小且可全量人工 triage。

  **核心推翻**：
  - parse_assertion（A42D40↔A44840）相似度 **1.00 零变化** —— EncAssertion
    子上下文重构（sub_A0FB90 0x628 分配 + 清 pcb_info+0x10 bit0x2000 + 拷贝）
    在 72.61（漏洞版）已全部存在 => 那是 66.54→72.61 间的**重构，非安全修复**。
    此前主攻方向正式关闭。
  - 0x6F/0x76/0x79 系列 +37/+52/+151 块增量 = 配置分发器兄弟函数 BinDiff
    循环误配（C 代码逐字节相同），非"共享校验插入"。

  **真正的修复（AAA/SAML 带内仅两处，均为 CWE-125 前置解析边界检查）**：
  1. **Redirect Binding 处理器（SP 角色，GET /cgi/samlauth 攻击面）**
     72.61 A3E200 ↔ 73.33 A3FE00（+27 块，sim 0.90）。66.54 对应函数
     sub_9F16B0（C 反编译成功）实锤漏洞构造：
     ```c
     if ( v8 - v7 < 0xD ) bail;              // 仅 13 字节下界！
     if ( "saml" + "encoding"                    // v7+0..v7+12
       && *(u64*)(v7+13)=="urn%3Aoa" ...         // 一路读到 v7+85 共 86 字节
       && *(u8*)(v7+85)=='e' )                   // 全字面量 "SAMLEncoding=
                                                 // urn%3Aoasis%3Anames%3Atc%3ASAML%3A2.0%3A
                                                 // bindings%3AURL-Encoding%3ADEFLATE"
         → DEFLATE 路径 (LABEL_5)
       else → 917508 "Unsupported SAMLEncoding algorithm seen"
     ```
     修复版在读取前新增 `if (end-(v7+13)) < 0x49 → 拒绝`（0x49=73=剩余 URN 长度）。
     **漏洞版把 8 字节粒度的 73 字节 URN 字面量匹配读出缓冲区末尾**，
     触发条件 = 查询串含截断的 `SAMLEncoding=urn%3Ao...`（剩余 13~85 字节）。
     73.33 还新增独立参数名字符串 "SAMLEncoding"（72.61 无此串）。
  2. **IdP 侧 AuthnRequest 解析器** 72.61 A34D90 ↔ 73.33 A36950（+11 块）：
     属性提取（AssertionConsumerServiceURL 等）前新增 `memchr(ptr,'>',remaining)`
     tag-end 校验（未找到 → 新错误 "tag end '>' not found"），替代以缓冲区末尾
     为界的旧逻辑；Conditions(NotBefore/NotOnOrAfter) 解析块重组。
  3. process_data（A12510↔A140F0，sim 0.94/+13 块）：仅为 encryptedKey/
     UnencryptedKey 失败分支重排 + 错误码(0xE0004/5/8/E)管线整理 + 新日志
     调用内联化，**无验证逻辑增删**（在导出可见的 3000 条指令范围内）。

  **其余全部变化归为特性/加固**（已逐类指纹识别）：OAuth IdP introspect/revoke/
  userinfo API 群（0x11B1/0x163C/0x1A86 新函数簇）、SPA CALLOUT_REQ、
  CVPN_V2_DHT 重写、PI 表达式引擎刷新（0x153-0x163 大改，"nested named
  expression" 等串）、HA PSK 派生、PCoIP SSIG 密钥长度检查、新增空指针安全
  访问器 sub_919CE0 等。

  **漏洞机制假说（与 CVSS 向量及版本矩阵吻合）**：
  SAMLEncoding 字面量 OOB 匹配在堆上"恰好"读出 URN 后续字节时 → 误选
  DEFLATE 解码路径 → 解码/验签使用的数据范围与实际参数背离 → 身份提取与
  签名验证作用于不同字节集 = CWE-288 认证绕过表现。无认证、无交互、
  PR:N —— 与公告一致；"需 SAML action"变体 = Redirect binding 处理器仅
  在配置 SAML action 时注册；≤43.55 无 SAML 变体推测为重构前该解析器
  位于通用 AAA 绑定处理层（待 13.1-48.47 验证）。

  **下一步 PoC（精确化旧"唯一未跑子分支"）**：
  `GET /cgi/samlauth?SAMLResponse=<b64>&RelayState=x&SigAlg=...&Signature=<合法URL签名>
  &SAMLEncoding=urn%3Ao`（截断值，总剩余 13~85 字节），配合堆布局使缓冲区后
  恰好排布 URN 后续内容；对照 = 完整 SAMLEncoding 值与无该参数。观察
  saml_tot_inflate_* 计数器与 917508/917504 错误分布。实验设备 66.54 已实锤
  存在此代码路径。
  （教训记录：BinDiff 文本导出的函数指标含兄弟误配伪影，C 级 diff 优先；
  INP.py 3000 条指令截断会隐藏函数尾部，全量结论需多版本三角验证。）
- [2026-08-27 PoC 实测（设备已升级 72.61 = diff 用的同一二进制）] 设备现为
  **NS14.1 Build 72.61.nc**（2026-06-23），与本轮 diff 的漏洞版导出完全一致。
  Redirect Binding 处理器全流程 C 级破译（66.54 sub_9F16B0 反编译 + 72.61 汇编核对）：
  **扫描/重建/验签/解压四段结构**：
  1. 参数扫描循环（memchr '&' 逐参数推进）：SAMLResponse 分支**总在重建缓冲
     qword_3032468 偏移 0 处 memcpy**（`v233 = v14+1` 重置式记录，**重复参数
     = 后者整体胜出**，无首/尾分歧 => 重复参数无法直接走私）；RelayState 分支
     仅当（已见 response 且未见 sigalg）时追加进重建缓冲（v240=1），否则进
     独立 relay 缓冲；SigAlg 追加并 v229=1；Signature 只 g lean 值+长度
  2. 无签名门：`!(v219|v234)` 时 action 字段+8(u16)!=2 => "Unsigned Assertion
     seen, denying"；==2 才走 LABEL_304 解压路径
  3. **URL 验签数据 = 重建缓冲**（"SAMLResponse=..&RelayState=..&SigAlg=.."）：
     SHA1/SHA256（v235==4/else）+ RSA（sub_1E05790）对重建串验证，成功后
     `goto LABEL_304`
  4. LABEL_304：从 **v218=重建缓冲+13**（"SAMLResponse=" 之后）URL 解码 =>
     base64(sub_801210, 上限 0x20000/最大值 u16@cfg+374900) => inflate
     （dword_2BF8024==2 ? sub_9DD8A0 : sub_FA37B0，计数器 361FC18/20/28）=>
     parse_assertion(sub_9F47F0) => XML 验签 sub_9E0DB0（v243+24/+60/+736/+772
     签名标志，无签名且 action 允许 => LABEL_476 直接收敛）=> 状态检查 =>
     会话。**验签与解析同源（同一重建缓冲）=> 纯重复参数/顺序攻击不构成
     验签-解析背离**。LABEL_304 的 URL 解码只解 %25（'2'/'5' 条件）= deflate
     variant 处理。
  **SAMLEncoding OOB 实测矩阵（poc_samlencoding_oob.py）**：
  | 测试 | 结果 |
  |---|---|
  | 完整 URN（L=73） | "Malformed Assertion"（编码接受→无签名拒绝 917509）|
  | 截断 sweep L=0..72 | **全部 917508** + ns.log "Unsupported SAMLEncoding algorithm seen"（local0.err）= **OOB 比较确定性执行**（读 query 末尾之后最多 72 字节）|
  | URL 长度 50~8100 扫描 | 全程同路径 => URL 与请求行同缓冲，**首个 OOB 字节恒为 ' '(0x20)**，'\|0x20' 小写化后不可能等于 URN 字符 => 请求帧内无法完成 OOB 匹配（HTTP/0.9 的 '\r'\|0x20='-' 只能匹配 v7+67 一个字节，随后 '\n'→0x2A 断链）|
  | 未知参数在 SAMLResponse 前 | **43549 (0xAA1D)** 分发错误（首参数嗅探决定 ReqType），在后则正常 |
  | 喷洒+簇边界对齐（X-Fill=URN×N 并发） | 无命中（无独立 URL 分配的证据）|
  | IdP 侧 AuthnRequest '>' OOB | 被 917517 "Matching policy not found" 策略墙挡住（本配置不可达解析器）|
  **结论**：SAMLEncoding OOB 读 = 确定性执行的 CWE-125（每次截断请求都触发），
  本配置下无法转化为可观察的信息泄露/绕过（URL 缓冲与请求行同置，首字节恒空格）；
  73 字节 URN 全匹配要求使纯远程利用需要堆布局控制。CVE 完整利用链（认证绕过）
  最可能需要：URL 独立分配的版本/路径 + 堆喷，或与第二个 CWE-125（IdP '>' 解析）
  组合。两个边界检查修复 = 73.33 对该 CVE 面的直接加固证据成立；"简单单请求
  绕过"与 CVSS AC:L 的矛盾仍未消解——真实修复可能还含 nsmgr 等未导出模块。
- [2026-08-27 情报修正 + CVE-2026-19489 校准 + nsppe 审计闭环] 公开情报确认：
  **CVE-2026-19490 = CWE-288（备用路径认证绕过），CVSS 9.3 AC:L（确定性）**，
  触发组件"认证处理路径"（SAML/AAA vserver）；同批 **CVE-2026-19489 = SIP ALG
  协议栈 + LSN 组内存管理**（CVSS 8.8）。=> 此前找到的两个 CWE-125 边界检查
  是同批加固而非 CWE-288 主修复。
  **CVE-2026-19489 在同一 diff 中命中（方法论校准 ✓）**：SIP ALG 区（72.61
  0xF6-0xF8）5 函数变更，其中 **ns_sip_parse_uri（sub_F75C90→F78B00，sim 0.79，
  374→471 行重写）** + F770B0(0.84)/F73C30(0.95)/F66A50(0.96) = SIP URI/头解析
  重写 = "LSN 组内存管理"修复的实质量级参照。
  **CWE-288 主修复在 nsppe 中不存在的证据链（全量审计闭环）**：
  | 审计项 | 72.61↔73.33 |
  |---|---|
  | 路由匹配器（/cgi/samlauth 引用者 sub_9F1A60/sub_9F3260）| **1.00 完全未变** |
  | SAML action 反序列化/查找（sub_1184850，"action name copied to samlaction"宿主）| **1.00**（仅日志表地址平移）|
  | process_data | 0.94 仅错误路径重排；**72.61 侧 2997 instr < 3000 导出上限 = 全量可见**（73.33 侧 3184，尾部 184 instr 不可见 = 唯一残留盲区）|
  | parse_assertion / nfactor_start_saml_auth | 1.00 |
  | 被删 sub_793DC0 | ns-aaa-vpn-appfw-analytics-profile 内置对象注册器（重构，非安全）|
  | CVPN 带（9C4500/B20A90/B225C0 低相似度"重写"）| **BinDiff 循环误配伪影**：真实配对（9C4500↔9C60F0）C 级相似 0.915 无实质变化；该带代码整体搬移致地址配对失效 |
  | 0x11B1 新函数簇（400/288/93 instr）| OAuth JWK CONF REFRESH 代理隧道特性 |
  | SPA 授权构建器 ADA410→ADC7B0（+127 块）| 特性演进 + 防御性空指针门（新增 [x+0x4B8] pcb_info 判空）；"PROXY: failed to allocate AAA PCB info" 新日志 |
  | 设备守护进程 | 14.1 无独立 nsmgr；config 层 = nsconfigd/imi（管理面，AV:N 未认证不应触达）|
  **判定**：CWE-288 主修复不在 nsppe 已导出部分。剩余可能：(a) 73.33 process_data
  尾部 184 instr 盲区；(b) 固件其他二进制（nsnetsvc/nsconfigd/imi/lo 面等 —— 需要
  **完整 73.33 固件**做全组件 diff）；(c) 版本矩阵"仅需 samlAction"变体指向的
  action 查找层在 PPE 中未变 => 反而支持修复在 (a)/(b)。
  **下一步（优先级序）**：
  1. 拿完整 14.1-73.33 固件包（.tgz）—— 全组件二进制 diff（脚本就绪）+ objdump
     补 process_data 尾部 184 instr
  2. 实验室加第二个 samlAction（rejectUnsigned=OFF、不同 IdP 证书）做 action
     选择混淆实验（错误 action 被选中 = 绕过面）
  3. 72.61 设备上的 nsppe/进程清单已核（nsaaad/nsconfigd/imi 在跑，可提取做基线）
- [2026-08-28 ultracode 全流重审 + 未认证 metadata 导出端点实锤] 113-agent 工作流
  （740 变更函数→737 triage→48 深挖→43 对抗复核→38 确认）+ 人工补挖结论：
  **次级修复（全部 66.54≡72.61 漏洞形、修复窗独有）**：RADIUS 三点溯源门
  （FE1020/FE25A0/FE4C60，MEDIUM-HIGH，"server 查找失败时 Identifier 改写仍执行
  且 Response-Authenticator MD5 验证被跳过"——备用路径跳过验证的字面形态，但保护
  对象是 RADIUS 匹配状态非 accept/reject）；session-hash 复合键截断修复
  （4E9570+AA30D0 双点，LOW-MEDIUM）；7F6890 UAF（同一 hash 表，key=
  "epa-v2-aes-key"）。
  **🔴 未认证 SP metadata 导出端点（本日核心发现，实机验证）**：
  - **`GET /metadata/samlsp/<samlAction名>` → 完整 SP 元数据（无认证）**；
    entityID/ACS(双绑定)/SLO 泄露 + action 名枚举 oracle（错名→"saml action
    is not found"）
  - 全管道破译：URL 分类器 sub_58BF10 前缀匹配 `/metadata/samlsp`→码35（仅查
    0-15 字节无终结检查+长度门≥18，故 /metadata/samlspXXXX 也进处理器但
    memcmp("samlsp/") 失败→"URL format error"）→ 分发器 0x7B64DD case35 →
    sub_A24120（名字精确查表 sub_1015A90 + 类型门 SP=5/7, IdP=5/10 或
    **0x1C/0x1D 宽门**）→ sub_A188E0 同步生成 → 发送；arena 变体 ctx ID
    0x3D6=982 = NS_ASYNC_CTX_AAA_UNAUTH_SAML_METADATA_SP_EXPORT（字符串自证
    "UNAUTH"）
  - **修复指纹三点闭环**：72.61 分类器只注册 samlsp(35)（samlidp 分支=死代码，
    `/metadata/samlidp/idp-prof` 到达处理器但查表命名空间不含 IdPProfile→404）；
    **73.33 分类器换成 samlidp(36)，SP 路由整体移除**；处理器本体 sim 1.00 未变
    ——修复=切断路由=典型"移除备用路径"（CWE-288 修复形态）
  - 与公告矩阵吻合：未认证✓ AC:L✓ "仅需 samlAction 无需 vserver 绑定"✓
    （metadata URL 只需 action 存在）；CERT-EU 2026-010 排查命令
    （grep `add authentication samlAction`）与我们的触发面一致
  - 配 signingCert（-samlSigningCertName sp-sign）后导出为签名元数据
    （KeyDescriptor×4+Signature×2，5400B）→ 证书获取路径可能启用异步变体
  **两段式绕过实测（全部未翻转未签名门）**：顺序 keep-alive、单段管道化、
  35s×550rps 并发竞态（元数据喷洒×未签名 POST）、签名证书异步变体——
  "Unsigned Assertion seen" 每次都在。管理员会话影响模型（CERT-EU/THN 情报）：
  NameID→本地用户映射（nsroot 存在）= 绕过落地后的提权机制；本配置下门翻转
  原语仍未找到，与 process_data 73.33 尾部 184 盲指令/固件其他组件假设一致。
  实验资产：/tmp/poc_meta_bypass.py、/tmp/poc_race.py（两段式+竞态）；
  设备新增 sp-sign certKey + kc-saml 绑定（未 save，重启即失）。
- [2026-08-28 循环猎洞 #1] `/loop zhao dao zheg lou dong,cve-2026-19490`
  （任务 92d03be3，每 10 分钟）本轮：
  - **sub_1015A90 查表语义修正**：遍历 qword_2DCD8B8 哈希表，匹配条件 =
    len(node+92)==namelen && memcmp 相等 && **node 类型字段==10**（authentication
    action 表）→ idp-prof 此前查不到是升级丢配置（已重建），非命名空间缺陷
  - **IdP 分支实机激活**：重建 idp-prof 后 `/metadata/samlidp/idp-prof` →
    未认证返回**已签名** IdP EntityDescriptor（exc-c14n+rsa-sha256）——
    漏洞版 SP+IdP 两个未认证导出分支都在线，修复只砍 SP
  - 0x1C/0x1D 宽类型门探测：`add authentication oauthIdpAction testoa` 创建
    成功但 `/metadata/samlidp/testoa` → "action is not found"（OAuth 对象不进
    type-10 表）→ **宽门 = 死代码，类型混淆不可达**
  - 设备状态：idp-prof + testoa(oauthIdpAction) 已加（未 save）
  下轮方向：process_data /cgi/samlauth POST 入口在分发器 0x7B64DD 的 case 号
  与入口校验（unsolicited 已知免 pending，唯一门=签名验证）；canon 单元共享
  假说的代码级验证（元数据签名与断言验证是否共用异步 canon 通道）。
- [2026-08-28 循环猎洞 #2 —— 认证路径第二二进制 nsaaad 浮出] 关键架构发现：
  **canon 异步往返 = nsppe→nsaaad IPC**。"AAA PDU saml canon: assertion length"
  （nsppe sub_7DE430 构建）→ nsaaad `saml_canon` 服务（socket 读取/canon_req
  解析/canonicalize_data/send_saml_canon_response）→ 响应回 nsppe 继续验签。
  Readme 追猎多年的 canon-pending 中断窗口 = AAAD 往返期间。
  **"Delegating saml auth to kernel" + send_saml_redirect**（nsaaad 0x4212F8/
  sub_42A460）= AAAD→内核 SAML 认证委托 —— 认证处理路径横跨两个二进制，
  此前项目只看过 nsppe！
  资产：/nsmgr_72.61/nsaaad（666KB FreeBSD ELF 已拉取+反汇编 92K 行，
  nsaaad.asm）。8766 监听 = **仅 127.0.0.1**（直连备用通道关闭）。
  **下一优先级：73.33 固件（双二进制 diff：nsppe 尾部 184 盲指令 + nsaaad
  全量）** —— 这是收官的唯一阻塞项。nsaaad 的 canon_req 解析器
  （0x429940 区域）待反编译审计（attacker 字节经断言到达）。
- [2026-08-28 循环猎洞 #3 —— canonicalize_data 审计通过] radare2 伪码+原始
  汇编审计 nsaaad fcn.00429720 = **canonicalize_data**（naaad.c，
  dprintf 自带函数名实锤）：
  ```asm
  429809: cmp $0x10,%rcx        ; token 索引 vs 16
  42980d: je  429a27            ; 第 17 个 token → 计数器++ 退出
  429813: mov %r13,-0xb0(%rbp,%rcx,8)   ; 最多 16 槽（rbp-0xB0..-0x38）
  ```
  **边界正确**（16 槽上限 + 栈金丝雀在 rbp-0x30 = 恰好下一槽，被排除）。
  语义修正：空格分词的是 arg3（exc-c14n 的 inclusive 前缀列表，对应 nsppe 侧
  "List of ... exceeds max limit" 日志），非 XML 本体；XML 走独立
  xmlParseMemory(全文)。**无内存漏洞**。
  下轮：r2pm 装 r2ghidra 或继续手工 —— 系统化过 nsaaad 全函数清单
  （afl），优先 auth 决策/委托/PDU 处理函数；nsppe 侧同步确认 canon 请求
  的组装点（sub_7DE430 调用者）。
- [2026-08-28 循环猎洞 #4 —— canon 链整体出局 + 唤醒 13.1 未执行方向]
  **canon 共享假说干净排除**：canon PDU 构建器 sub_7DE430 仅 3 个调用者
  （process_data@A14D93 + sub_9F04F0 + sub_9FE6D0，后两者也在断言验证路径），
  元数据签名器 sub_A188E0 不在其中；且三个调用者 + 构建器 + nsaaad
  canonicalize_data **全部跨修复边界 sim 1.00 零变化** —— canon 基础设施
  整体与修复无关。
  nsaaad 协议头破译：process_kernel_socket = recv 24 字节定长头
  （magic 0xdeadbabe + u16 session + u32 + **u16 命令字** + 长度字段，
  长度校验 [0x18,0x10000) 且 != 0x27）。
  **唤醒未执行方向（重要）**：13.1-48.47 导出就在本地 nsppe_analysis/ ——
  2026-08-24 复盘明确的"下一步"（非 SAML 通用认证路径：表单登录/会话建立/
  tmlogin/证书认证）**从未实际执行**（当时转去二进制 diff）。≤61.27 变体 =
  只需 vserver 无需 SAML = 原始漏洞形态。下轮主攻 13.1 通用 AAA 路径。
- [2026-08-28 循环猎洞 #5 —— 13.1 通用路径首探 + TM 密钥架构] 13.1 导出为
  legacy 格式（decompile/ 每函数一文件 + function_index.txt 带符号名）：
  - **ns_aaatm_process_tmselfauth (0x95A550)**：TM 自认证 = 通用 AAATM 机器
    （无需 SAML 绑定），核心 = `ns_aaa_vpn_samlart_lookup`（SAML artifact
    DHT/GSLB 查询）→ 数据魔法比较（0x3D74736F707F7369 类）→ 构造
    tm_aaas_cookie_str + **RC4(aaa_tm_rc4_key, ssid)** —— artifact→TM 会话
    的桥接器；调用者 0x7419F0/0x95CEF0
  - **TM 密钥架构破译**：`ns_nwaas_init`: `strcpy(&aaa_tm_rc4_key,
    "NETSCALERTMAACKYNETSCALERTMASCKY")`（32B = tm key + tm_secure key 两个
    相邻 16B 键的硬编码默认）；`ns_aaa_init_keys`: **仅 `!local_targetid`
    （PE0）才 RAND_bytes 随机化**，非零 PE 靠同步（72.61 = sub_5DDEC0
    `key=*(msg+32)` 接收器）。三版本（66.54/72.61/73.33）该常量+架构均存在
    → **非修复点，标准初始化架构**；残余问题 = 对等同步是否覆盖全部键
    （部署相关，非 CVE）
  - sess_id= URL 机制 = RFE/bookmark 测试残留，非认证路径
  13.1 下轮继续：表单登录处理器（/cgi/login 凭据路径）、会话建立的调用者
  枚举（缺凭据门的调用者）、证书认证、以及 tmselfauth 两个调用者的入口
  URL 与门条件。
- [2026-08-28 循环猎洞 #6 —— ≤61.27 变体状态机全图] 13.1 通用路径核心映射：
  ```
  ns_aaatm_handler (0x95DD90, 26KB 主处理器)
    └─ ns_aaatm_process_unauthenticated_req (0x95CEF0)   ← 未认证请求总入口
         ├─ a4==5 → NS_ASYNC_CTX_AAATM_SELFAUTH(856) → ns_aaatm_process_tmselfauth
         │            └─ samlart_lookup → blob 魔法 "is_post=" → RC4(tm_key) 铸 TM cookie
         ├─ ReqType==16386(samlauth)&&len==13 → logout 串响应
         ├─ !a3+2605 && !a3+3996 → CTX_HANDLE_UNAUTH_FORMS(854) → _forms 处理器
         └─ v33+89&1 → CTX_AAATM_CERT_AUTH(855) → 证书认证
  ```
  - vserver 上下文字节 **+0x1AA == 5** = selfauth 家族的 vserver 级模式门
    （ns_aaatm_handler 95DDE2）；另有 +0x91&0x10 位门
  - **tmselfauth 的 artifact 存储魔法破译**：`(blob|0x2020...) == 0x3D74736F707F7369`
    = "is_post="（0x7F 位对应 '_'）—— 存储内容含 is_post 标志 = SAML artifact
    流程写入的会话迁移数据
  - **≤61.27 变体攻击形状假设**：向 samlart 存储注入受控内容 + 触发 vserver
    state-5 路径 = 免凭据铸 TM 会话（待 tmselfauth 220-460 行验证链核实）
  下轮：读 tmselfauth 完整验证链（95A550 L220-460：lookup 后到 cookie 铸造
  之间的所有检查），以及 72.61 上的对应函数定位+实测。
- [2026-08-28 循环猎洞 #7 —— tmselfauth 验证链全图 + 排除] 13.1 验证链
  完整破译（10 道门）：samlart_lookup 成功 → 魔法 "is_post=" + len>10 →
  "tsd="（0x3D647374）→ "tmaa" 段扫描（CSRF 存在性）→ Host 头匹配
  （ns_aaatm_tmselfauth_verify_host）→ auth vserver 查找 → "htonly" 参数 →
  "Profile" 参数 → tmaa cookie 值校验 → 从解析数据拷贝 + RC4(tm_key) 铸造。
  存储 blob 格式 = `is_post=tsd=<时间戳>...tmaa=<cookie 材料>...&htonly=..
  &profile=..&vserver=..`（序列化的 POST 重建）。信任锚 = samlart 存储内容
  （仅认证后 SAML/artifact 流程写入）+ RC4 键。注意：CSRF 检查疑似只验
  "存在性"不验值。
  **排除**：72.61 对应函数 = sub_7B15F0（"SelAuth" 串定位），**sim 1.00
  flags '-------' 跨修复边界完全未变** —— selfauth 路径非修复点。
  **排除清单累计**（全部 1.00/仅加固）：SAML 核心 / action 层 / canon 链 /
  tmselfauth / TM 密钥架构 / URL 匹配器。=> 修复面进一步收敛到：73.33
  process_data 尾部 184 盲指令 + 固件未导出组件（nsppe 之外的二进制）。
  未认证 metadata 端点移除仍为唯一已归因的修复工件。
- [2026-08-28 循环猎洞 #8 —— 184 盲指令盲区闭合！] 发现 diff_work/pd_fixed.c
  （8月22日 IDA 会话产物）= **73.33 process_data 全量汇编 3185 行**（无导出
  上限）——尾部 190 条指令首次可见，内容 = **EncryptedAssertion/HOK/FIPS
  异步续体状态机**（"SAML: FIPS offload…"/"HOK SSO Issuer seen…"/
  "API returned different…" 错误族 + ctx 0x440/441/442 状态 park/resume +
  FACEF00D 魔法 + 光标界检查）。
  **决定性对照（72.61 全量 asm vs 73.33 全量 asm，尾部逐项）**：
  | 项 | 72.61 | 73.33 |
  |---|---|---|
  | EncAssertion 异步状态 | **2 个（440h/441h）** | **3 个（440h/441h/442h）** ←新增 |
  | 后续状态族 | 473h×3 | 475h×3（重编号）|
  | 0x440 park 的异步调用 | sub_CD5310 | sub_CD7320（换了对象）|
  | 66.54 参照 | 442×1,443×2,444×2,445×2（另一套分配）| — |
  **解读**：非重编号 —— **修复版在 EncryptedAssertion 解密路径新增了一段
  异步阶段（状态分裂）**，与长期假设（enc 路径状态机重构）精确吻合，且
  落在此前所有分析都看不到的导出截断区。旧会话"445h→442h 重编号噪声"的
  判断是误读（实为新增状态）。
  武器化方向（72.61）：0x440/441 park（sub_CD5310 解密派发）期间的续体
  混淆 —— 粗粒度状态 = 恢复点错位 = 验证跳过窗口。这为两段式攻击提供了
  精确目标（不再是盲打 EPA/tmlogin）。
  **修复归因最终图景**：① 未认证 metadata 路由移除（URL 分类器）+
  ② process_data EncAssertion 异步状态分裂（本轮）+ ③ 两处 CWE-125 边界
  加固 —— 三件套构成 73.32/73.33 对 CVE-2026-19490 的完整修复面。
- [2026-08-28 循环猎洞 #9 —— 纠正 + 状态机精确对照] **纠正上轮"新增状态"
  的过度解读**：全量枚举证明三版本各 6 状态（66.54: 442-446+478 / 72.61:
  43D-441+473 / 73.33: 43F-443+475）—— **枚举全局重编号**（他处增删异步
  ctx 类型导致的整体漂移），非新增状态。但 park↔resume 语义映射仍需逐状态
  核对（见下）。
  **72.61 park/resume 布局首查（每状态 1 park + 1 resume，配对完整）**：
  | 状态 | park 写入字段 | park 调用 |
  |---|---|---|
  | 0x440 | +0x74,+0x7C,+0x84,+0x8C（4 字段）| call CD5310 |
  | 0x441 | +0x74,+0x7C,**+0x94**,+0x8C | **无直接 call**（jmp A15CFB 转入清理/别处派发）|
  | 0x43E | +0x9C,+0x84（仅 2 字段）| call CD5310 |
  resume 侧：cursor += 0x38 → FACEF00D 魔法 → 边界 → 下一槽 ID ∈[172,172+0x6EC)
  链校验 → 专属 continuation。首轮看 park↔guard 配对正确。
  **待查（下轮）**：① 各 resume 的字段读取与其 park 写入布局是否一致
  （读 +0x94 而该状态没写过 = 未初始化消费）；② 0x441 park 为何无 call
  （其异步操作在哪派发）；③ 73.33 同表对照 —— 语义差异点。
- [2026-08-28 循环猎洞 #10（进行中，状态保存点）]
  - sub_CD5310(72.61) ≡ sub_CD7320(73.33) = **阶段步进器**（`*(ctx+5292)++`
    计数器，前两次进入触发动作）—— EncAssertion 解密管线由 +5292 阶段
    计数器驱动，6 状态机 = 多阶段管线
  - **进行中工作流** `ctx-state-machine-audit`（wf_6a44ee7f-2c4，TaskID
    wmn8ymfa2）：3 版本并行提取 park/resume 全表（字段布局/park 调用/
    continuation 读取）+ 对抗复核。结果将写入本文件
  - **实验室配置漂移（未 save，重启即失）**：sp-sign certKey 已建 +
    kc-saml 绑定 -samlSigningCertName sp-sign；idp-prof（samlIdPProfile）
    已重建；testoa（oauthIdpAction）已建。Readme 既有配置 + 以上漂移 =
    当前设备状态
  - 关键资产路径备忘：/tmp/pd61_full.txt（72.61 process_data 全量 asm，
    可从 nsppe-14.1-72.61 导出重新生成）；diff_work/pd_fixed.c（73.33 全量
    asm）/pd_vuln.c（66.54 全量 asm）；bindiff_review/（740 变更函数队列）；
    nsmgr_72.61/nsaaad(+.asm)（AAAD 守护进程反汇编）
- [2026-08-28 循环猎洞 #10 完成 —— ctx 状态机审计工作流终审] 工作流
  wf_6a44ee7f-2c4（3 版本 × 6 状态全表 + 11 项对抗裁决）结论：
  **① 布局层全清白**：三版本六态 park/resume 字段集严格配对（66.54 -5 →
  72.61、73.33 +2 的均匀 ID 漂移，每角色布局/调用形状跨版本相同）——布局
  非修复点。
  **② 唯一的 park 代码语义修复（寄存器生命周期缺陷）**：
  ```
  72.61 (漏洞): 473-park @A1623B 写 +0x74 ← rdi
     —— 但守卫失配 fallthrough 上，之前的日志调用 sub_1B08E30 已破坏 rdi
     —— park 进去的是垃圾指针，下次 resume 当解密缓冲用 = 野指针/UAF
  73.33 (修复): +0x74 ← r14（callee-saved，跨日志调用存活，全路径有效）
  66.54: 也安全（rbx 在分支前预载）
  ```
  **③ fail-open 守卫极性（中等置信 CWE-288 机制，全部指令级验证）**：
  弹帧后三重校验的极性：(a) FACEF00D 失败 = fatal ✓；(b) **cursor 越界
  (≥arena+0x68) → 静默进 continuation，ID 校验整体跳过**（sub_40D0C0 反编译
  佐证：fatal 嵌套在 `v17 < arena+104` 之内）；(c) 下一帧 ID 只做 **范围测试
  [0xAC,0x798)（1677 个值）非精确匹配** —— 六个合法状态全在窗内 ⇒ **堆叠/
  乱序帧可链式通过校验**（结构证明：0x43E 续体 A15371 直接落入 0x473 守卫
  A1538F）；(d) 473 链校验的"下一 ID"是**从未写入的 +0x84 陈旧字段**。
  **机制定论**：漏洞版的 SAML 解密/HOK 状态机 = fail-open 恢复 + 失配路径
  park 野指针 —— 跨请求上下文混淆的完整材料；修复 = r14 寄存器修复 +
  metadata 路由移除 + CWE-125 加固三件套。武器化链条（堆叠触发 → 认证决策
  跳过）结构上强暗示但未端到端演示 —— 攻击序列构造 = 剩余工作。
  （附注：pd_fixed.c 实际也截断于 3000 条 @A17E6F，代理从 73.33 导出
  decompiled.c 1232039-1235216 行恢复了完整函数并交叉验证。）
- [2026-08-28 循环猎洞 #11 —— 分配器几何 + 确定性攻击草图] 工作流完整状态表
  补充关键事实（72.61）：
  - **0x441 = SAMLResponse 解析阶段 park**（sub_A12290 反序列化期间），且
    **函数中段入口 A12AC5-A12ADD**：初始解码期间竞技场非空 → 直达 0x441
    守卫 = **跨请求恢复点**（下个请求恢复上个请求的解析帧）
  - 阶段链：**441(解析)→440(Response验签)→43F(断言验签)→43E(HOK外层)→
    473(HOK证书)** 串联 park；验签续体 re-call sub_A3B050
  - **分配器 sub_15EC400**：arena 已活时二次分配 = fatal("Invalid async
    block.")；容量 **0x1FFFFF (2MiB) 创建时固定**写入 arena+0x68；**park
    推进 cursor 无界检查**（越界几何可行）；arena 释放仅在 43D 终态
    （sub_15EC4C0）
  **确定性攻击草图（待验）**：
  1. 请求 A：构造使验签/解析阶段 park（有签名响应或巨型响应），随即 RST
     断连 → park 永不恢复 → arena 泄漏（帧滞留，limit 固定）
  2. 请求 B（新连接）：伪造未签名响应 → process_data 入口见活竞技场 →
     **恢复 A 的帧**（中段入口或顶层分发）→ 续体继续 → park 后续阶段
     （cursor 在固定 limit 上继续增长）→ cursor ≥ arena+0x68 → **链校验
     静默通过（fail-open）** → 会话从 B 的伪造内容建立？
  待验证核心：OOB 静默通过路径是否绕过验签结果消费（续体 A1503B 仅在
  arena 非活时检查 eax 验签结果）。下轮：沿 OOB-pass 路径追到会话建立点。
- [2026-08-28 循环猎洞 #12 —— 最后一跳映射 + 实验室离线] verdict 消费点
  终图：
  - 0x440 验签续体：`A1503B: test eax,eax; jz A15909`（错误出口）——
    **仅当 re-call A3B050 后 arena 同步死亡时执行**；arena 活 = 再 park，
    eax 不查
  - 0x43D 解密终态：释放竞技场后读**全局标志 xmmword_303D980**（FIPS 结果
    标志）：置位→A14E47 sub_A42D40（验签续跑）；为 0→计数器++→return 0x20
    （无会话）。全局标志作 verdict = 潜在陈旧标志模式（PE 级跨请求共享）
  - **RST 泄漏实验已构建**（/tmp/poc_rst_leak.py：带签名结构的响应触发
    验签 park + SO_LINGER(0) 立即 RST ×15 + 逐次异常探测；成功信号 =
    探测响应偏离 "Malformed" 或 ns.log 出现 "Invalid async block"/
    "Async context ID" fatal）
  - **⛔ 实验室离线**（192.168.190.30/.31 全部 100% 丢包，2026-08-28 ~
    16:00 EST）—— 环境关闭或网段变动。设备恢复后：直接跑
    /tmp/poc_rst_leak.py（无需其他准备）
- [2026-08-29 循环猎洞 #13 —— 🎯 陈旧暂存门：确定性单请求绕过候选] 深挖
  0x43D 终态的 verdict 源：
  ```asm
  A145C3: mov r13d, dword ptr cs:xmmword_303D980   ; verdict = 共享暂存首 dword
  A145D3: jnz  A14E47                                ; ≠0 → 验签续跑 sub_A42D40
  ```
  **xmmword_303D980 = 全局共享工作缓冲（64KB+，全二进制 207 处引用）**：
  - 写入者横跨 0x4D/0x4F/0x98/0x99/0x11C 带（含 11C37EE 写字面量 "type"、
    991C96/9950BF 写 16 字节 xmm0）
  - **process_data 序言的 SAMLResponse base64/URL 解码（sub_83BF40）输出
    就写这个缓冲**（4B8270 宿主同样用它解码+解析）
  - 解码输出首 dword = "<?xm" (0x6D783F3C) ≠ 0
  **若解密/canon 完成不回写该缓冲**（待证：找解密响应接收器是否写 303D980
  —— 若不写），则 43D verdict 门读到的是**本请求自己序言解码留下的非零值**
  = 解密成败判定被确定性短路 —— 单请求、零竞态、无竞态窗口！
  这同时解释 Readme 旧观察"解密链通"的异常顺滑（66.54 时代 EncAssertion
  公钥加密链一次就通）。
  **攻击链（设备恢复后验证）**：
  1. POST SAMLResponse=<任意 base64>（序言解码污染 [303D980]≠0）
  2. 同请求内 EncAssertion 路径（解密无论成败）→ 43D 终态 → verdict 恒通
  3. 下一道门 = sub_A42D40(r15, r13d=污染值, rbx, 1, &var_C0) —— r13d 作为
     参数进入验签续跑（污染值可能同时是长度/类型混淆材料）
  待证三点：① 解密响应接收器是否写 303D980（不写=门恒通）；② A42D40 的
  r13d 参数语义；③ 66.54 同址对照（该门是否修复版改动）。
  **③ 已答（2026-08-29）**：66.54 verdict=@0x2F88A60、72.61=@0x303D980、
  **73.33=@0x3068570 —— 三版本同一共享暂存模式，仅地址漂移，非修复点**。
  含义二选一：(a) 解密完成确实回写缓冲，陈旧窗口为空（架构视为良性）；
  (b) 该门在修复版仍可短路 = **修复不完整的独立发现**（若实证成立）。
  设备恢复后的判别实验：POST 纯 base64 垃圾（污染暂存）+ POST 垃圾
  EncAssertion（解密必败）→ 观察 0x43D 终态走向（计数器 qword_3707140
  增长 = verdict 正常为 0 = 走"陈旧为空"分支；不增 = 门被污染值短路）。
- [2026-08-29 循环猎洞 #14 —— 实验室恢复 + 判别实验完成 + 🔬 重大 scoping
  结论] 实验室恢复（72.61，sp-sign 绑定仍在，设备未重启）。三连实验：
  | 实验 | 结果 |
  |---|---|
  | RST 泄漏 ×15 | 无崩溃/无 "Invalid async block"/后续请求正常 —— **无 park 发生** |
  | 垃圾 EncKey | 917519 EncKey 解密失败（早期同步退出，未到 43D）|
  | **有效 OAEP EncKey + 垃圾数据** | **"successfully decrypted encryptedKey of size 32" → "Successfuly decrypted assertion of length 495"**（垃圾 512B 数据被"成功解密"为 495B —— **无填充校验，仅查非空**）→ 解密产物 XML 解析失败 → 917509 |
  **🔬 scoping 结论（解释全部历史黑盒失败）**：VPX 无 FIPS 卡 ⇒ 解密/验签
  **完全同步执行** ⇒ 异步竞技场（0x43D-0x441/473）**从不创建** ⇒
  fail-open 链校验/陈旧暂存门/473 野指针 park **在本实验室配置上不可达**。
  异步状态机攻击面需要 FIPS/HSM 卸载（或触发异步的其他条件：GSLB 模式/
  集群）才激活。武器化验证需要 FIPS 硬件或找到激活异步的配置。
  附带发现：AES 解密无 PKCS7 填充校验（乱码也"成功"）+ 解密长度日志泄露
  （495 = 512-16IV-1?）—— 低危质量问题，非绕过。
  攻击面总结修正：实验室可复现面 = 未认证 metadata 导出（已实锤+修复
  归因）；不可复现面 = 异步状态机混淆（需 FIPS）。
- [2026-08-29 循环猎洞 #15 —— 三线推进：①激活条件修正 ②FIPS ③13.1]
  **① 异步竞技场激活条件（修正 #14 结论）**：
  - canon/解密 PDU（sub_7DE430）的发送门 = 全局链表（ns_begin+778332）
    存在 state==7 的 nsaaad 连接 —— 实验室满足
  - `saml_decrypt_tot_success=1`（我的 OAEP 测试）证明**队列→park→nsaaad→
    resume 全循环确实运行**（单 tick 内完成 = 日志看似同步）
  - **#14 的"无 park"结论错误**：park 发生但 intra-request 完成；RST 失败
    是窗口太紧而非 park 不存在
  - 饱和实验（3 波 × 40 并发 × 100KB EncAssertion × 0/30/200ms RST）：
    全部探测正常、零 fatal —— **loopback+软件解密下窗口≈0**（100KB AES
    解密也是 µs 级）
  - **窗口开启器 = GSLB 远程模式**（NS_ASYNC_CTX_AAATM_SELFAUTH_GSLB /
    "GSLB Connection is being proxied"）—— 网络 RTT 窗口；实验室方案：
    Kali 假 GSLB peer（accept 后不响应 = 无限窗口）→ park 永久滞留 → RST
    → 泄漏 → 混淆攻击。待搭：add gslb site/peer 指向 Kali listener
  **② FIPS 硬件**：VPX 不支持 FIPS 卸载（MPX-FIPS 专属）；GSLB 假 peer 是
  实验室等效替代（同样打开异步窗口）
  **③ 13.1 通用路径**：未认证请求处理器的 FORMS 分支
  （ns_aaatm_process_unauthenticated_req_forms）+ CERT_AUTH 分支未审 ——
  下轮主攻（/cgi/login 表单凭据路径 = ≤61.27 变体的核心）
- [2026-08-29 循环猎洞 #16 —— 🎯 IdP 全流程实验室激活 + 双侧 OOB oracle 齐]
  **重大进展：Citrix-as-IdP 攻击面在实验室完全激活**（此前只有 SP 面）：
  - 配置恢复：idp-prof（已有）+ `add authentication samlIdPPolicy idp-pol
    -rule true -action idp-prof` + bind 到 nsvpx/av-saml（升级丢失，已补）
  - **IdP AuthnRequest 端点 = `/saml/login`**（从 /metadata/samlidp/idp-prof
    元数据提取；Redirect+POST 双绑定）
  - **URL 签名用 gw.key（实验室自有）打通全流程**：SAMLRequest(deflate+b64)
    +RelayState+SigAlg RSA-SHA256 → 签名验证通过 → 302 /vpn/index.html
    （登录墙）—— 完整日志链：ParseAuthnReq → issuer 匹配 idp-prof →
    （无签名=917669 拒；时间错=917665 拒）
  - IsPassive/ForceAuthn/组合变体：全部同样 302 登录页（用户认证墙稳固）
  - **IdP 侧 SAMLEncoding OOB oracle 上线**（A003D0 = 修复版已修的下溢读）：
    签名不含 SAMLEncoding（规范）→ 自由截断扫描：L=73/空=接受(302)，
    L=6..60=Malformed 拒绝 —— **与 SP 侧完美镜像，OOB 比较确定性执行**
  - 附：artifact 后通道观察（GET /cgi/samlart → "Couldnt open server
    connection"（URL 空=无元数据，917511）；GET /cgi/samlauth?SAMLart →
    43549 分发错误）；APPFW ns-aaa-spec 端点校验层显形
  **攻击面终图（双侧全活）**：
  | 面 | 端点 | 门 | OOB oracle |
  |---|---|---|---|
  | SP | /cgi/samlauth (POST/GET) | URL/XML 签名 | SAMLEncoding ✅ |
  | IdP | /saml/login (Redirect/POST) | AuthnRequest URL 签名（gw-cert 验） | SAMLEncoding ✅ 镜像 |
  | artifact | /cgi/samlart (GET) | 后通道签名+摘要（旧证） | - |
  | metadata | /metadata/saml{sp,idp}/<action> | 无（未认证导出） | - |
  下轮：① IdP 侧 XML tag-end OOB（A34D90 修复点）带签名截断扫描；② 双侧
  OOB 的堆控制完成实验；③ /saml/login 的 SignatureValue/SigAlg 变体矩阵。
- [2026-08-29 循环猎洞 #17 —— ACS 日志 oracle 实验（阴性）] IdP 侧带签名
  截断扫描（ACS 属性值内 8 个切点）：解析器提取的 acs=<...> 值 = **恰好
  等于截断输入**（acs=<https> / <https://192.168> / <...31/ad>），无堆字节
  出现 —— 属性提取以缓冲区末尾为界（in-bounds），tag-end OOB（A34D90
  修复点）在此 oracle 上不可见泄漏。截断请求全部被拒（Malformed）。
  IdP XML 解析器的 OOB = 修复确认但不可远程观察（与 SP 侧 SAMLEncoding
  同结论：确定性执行、无内容泄露面）。
- [2026-08-29 循环猎洞 #18 —— nFactor REST 面复活 + NSC_CERT 显形] 版本
  矩阵锚点（"≥43.56 需配置 SAML Action"）指向 action 存在性开启的路径：
  - **`/nf/auth/doSaml.do`**（73.33 新字符串清单成员）：无 query→500 43549；
    ?response=json→404 —— 端点在 72.61 已存在
  - **REST 复活配方**：先 GET /vpn/index.html（→302 /logon/LogonPoint/
    tmindex.html，**Set-Cookie: NSC_DLGE/NSC_USER/NSC_CERT**——NSC_CERT 正是
    73.33 新字符串清单里的 cookie 名，72.61 门户初始化即种）+ 带 Cookie/
    Referer 重打 REST → 从 43549 变为 302 Location:/（HTTP/1.0 旧处理器
    响应）—— 到达 nFactor 机器但需 tmindex JS 上下文（43KB 页 + ctxs.core
    JS 栈）才能进 doSaml 流
  - 下一步：复刻 init.js 的 REST 调用（或无头浏览器驱动）进入 doSaml 因子
    流 —— 该流 = "需要 SAML Action"变体的最直接入口（action 由因子解析）
- [2026-08-29 循环猎洞 #19 —— 🔧 全套攻击工具重建 + 会话建立 + XSW 矩阵]
  **saml_signer2.py 重建完成**（/home/kali/Desktop/citrix_/saml_signer2.py：
  exc-c14n(lxml exclusive)+enveloped+RSA-SHA256+断言内嵌签名，kc-realm-priv）：
  - **设备接受，完整会话建立**：unsolicited POST → 302 + NSC_AAAC +
    "SAMLSP: LOGIN SUCCESS; user <samluser>"
  - **NameID 完全任意**：nsroot / administrator / nonexistentuser99 全部建会
    （无本地用户校验，会话用户=断言字符串）—— 影响模型（任意身份会话）确认
  - **XSW 矩阵 8 变体**（72.61 首测，旧矩阵只在 66.54）：evil-before/after、
    signed-in-Object、evil-wraps-signed、in-Extensions、in-Advice、嵌套
    Response、signed-lookalike —— **全部解析层拒绝**（多断言结构直接
    Malformed，未到验签）—— 72.61 的 parse_assertion 重构对 XSW 免疫
  - Keycloak 在运行（无头浏览器走到登录页）；nFactor REST 需 tmindex JS
    上下文（chromium 表单不安全插页阻断自动流程）
  实验资产：saml_signer2.py（可铸任意 NameID 合法断言）= 后续所有绕过
  实验的标准工具；/tmp/xsw_matrix.py（XSW 框架可扩展）。
- [2026-08-29 循环猎洞 #20 —— EncAssertion 端到端打通 + 混淆变体矩阵]
  **基线（新能力）**：内层合法签名断言 → AES256-CBC(IV+密文) + RSA-OAEP
  (sp-sign 公钥，取自未认证 metadata 导出) 包裹密钥 → POST →
  "Successfuly decrypted assertion of length 1944" → **LOGIN SUCCESS +
  NSC_AAAC 会话** —— EncAssertion 全链路（未认证取公钥→加密→解密→验签→
  建会）在 72.61 完整复现。
  **混淆变体（73.33 修复主战场 = 子上下文隔离地形）**：
  | 变体 | 结果 |
  |---|---|
  | A: 解密内容=Response+未签名断言 | Malformed（结构拒）|
  | B: 合法签名块+篡改 NameID（签名引用旧内容）| **verification failed —— 摘要校验精确捕获篡改** |
  | C: 合法签名断言+evil 未签名对 | Malformed（多断言拒）|
  结论：72.61 的子上下文隔离对这三类混淆免疫；内层验证密码学健全。
  漏洞版特有增量（r14 野指针 park）仍需异步窗口（FIPS/GSLB）—— 与 #15
  结论一致。EncAssertion 精确攻击轮（工具完备后）收官。
- [2026-08-29 循环猎洞 #21 —— 任务#6 被许可证阻塞 + TMAA 伪造阴性]
  - **GSLB 功能未授权**（"Feature(s) not enabled [GSLB, LB]"，VPX 基础许可
    不含 GSLB；`add gslb site` 强制密码也拒）—— **假 peer 开窗路线被
    许可证挡死**。替代：GSLB 授权 VPX / FIPS 硬件 / NGS service-node 模式
  - Kali 假 peer 监听器已就绪（/tmp/fake_gslb_peer.py：3010/3011/8443/8888
    accept-hold，80/443 已被占用）
  - **TMAA 硬编码密钥伪造**（纯 py RC4 "NETSCALERTMAACKY" + IPv4-Kali 令牌
    3 种格式）：全部静默 302（无 "GSLB info corrupted" 日志，即使
    syslogParams -logLevel ALL）—— 令牌格式需从 13.1 95A550 尾部
    （tm_aaas_cookie_str 构造）提取后重测；或 /cgi/tmlogin 根本未进
    selfauth 机器（302 先行）
  **当前阻塞总表**：异步窗口开法（GSLB=许可证/FIPS=硬件）+ TMAA 令牌
  格式（13.1 静态提取）+ 13.1 无 SAML 变体（需 13.1 环境）。
- [2026-08-29 循环猎洞 #22 —— TMAA/store 格式终局 + 表单处理器两发现]
  - **TMAA 伪造路线关闭**：95A550 尾部 = selfauth 从 store blob 重新铸造
    cookie（"profile=" LE 常量 + 32B 块 + RC4 ssid 段 +
    ns_prepareGenericCookieperFQDN）—— store 由认证后 artifact 流程写入，
    cookie 格式由注入方决定，伪造无门（格式提取失去意义）
  - **表单处理器 95BE70 两发现**：① SAML artifact/assertion 结果在
    **NS_ASYNC_CTX_AAATM_OAUTH_LOGIN(862) ctx 下处理** —— 跨流 ctx 类型
    复用（SAML 结果吃 OAuth 登录的 ctx 槽型）；②
    `sslvpn_login_success_handler` 调用前 aaainfo+384/+392 被
    **authn_vserver+44 指针整体覆写**（登录状态注入/会话指针换绑）——
    两者的可利用性均系于异步机器激活（同窗口阻塞）
  **猎洞 22 轮总结**：静态修复归因 + 实验室全部未认证面测绘 + 全套进攻
  工具重建（签名/加密/会话建立/XSW/混淆矩阵）+ 机制级终图（fail-open/
  野指针 park/verdict 消费点）+ scoping 判定（异步窗口=FIPS/GSLB 专属）。
  无阻塞剩余项为零 —— 后续推进全部依赖：GSLB 许可证 / FIPS 硬件 /
  13.1 环境 / 73.33 完整固件。
- [2026-08-29 循环猎洞 #23 —— GSLB 解锁 + MEP 建立阻塞] **GSLB 功能
  已解锁**（`enable ns feature GSLB` —— 22 轮的"许可证阻塞"实为未开
  开关，#21 结论修正）：
  - 已配：REMOTE 站 kali-site(192.168.190.131, sitePassword) + LOCAL 站
    local-site(192.168.190.40 SNIP 新建) + svc-kali + gv1 vserver
  - **MEP（TCP 3011 metric exchange）不建立**（MEP Status: DOWN，
    netstat 无到 190.131 的连接，tcpdump 无流量）—— NS 未发起连接；
    原因待查（RPC 密码协商？需要 remote 端先宣告？snip 路由？）
  - TMAA 伪造（local-site IP 变体）：仍静默 302
  下轮：MEP 排查（set gslb site local-site -nwMetricExchange ENABLED
    / 查 MEP 端口实际值 / RPC node 密码同步），或直接看 13.1 代码中
    MEP/AAA-GSLB 连接建立条件
- [2026-08-29 循环猎洞 #24 —— AAA-GSLB 代理架构 + APPFW 拦截] 静态破译：
  AAA-GSLB 代理 = ns_aaa_do_gslb_processing → nsgslb_httphandler(0x100EA40)
  → **nsgslb_doredirects_doconnproxy(0x1010160)** → loadbalance_handler
  （**通过 LB 引擎**向目标发连接，非独立 RPC）。节点结构：+844=IP、
  +848=port(u16 网络序)。同步发现：**APPFW ns-aaa-spec 在 72.61 拦截
  /cgi/tmlogin**（"Parameter value incorrect as per API Spec" blocked —
  13.1 无此行为，这本身就是个值得记录的变化），改走 /vpn/tmlogin 绕过
  但仍 302 generic。TMAA 伪造 6 变体全部静默 302。
  下轮：MEP 连接排查（可能需要 -nwMetricExchange 或 RPC 密码同步）或
  从 pcb_info+0x1AA=5 的设置者入手找 selfauth 的真实触发请求形态。
- [2026-08-29 循环猎洞 #25 —— pcb 状态机 setter 破译] pcb_info+0x1AA 的
  写入者（全二进制）= **nsmysql_handler(0xDC5740)** 与 nsmssql_handler
  (0xDB1F60) —— MySQL/MSSQL 协议处理器！（值 1/2/5/8/9/0Ah/0Bh/0Ch）。
  HTTP 处理器（nshttp_req_hdr_handler）+ ns_aaatm_handler + cacler/sincmp/
  sso 只 **读** 该字段检查 ==5。⇒ **pcb_info+0x1AA=5 是数据库协议状态
  （MySQL "COM_QUERY ready" 状态 5），不是 AAA selfauth 状态**。
  之前 #6 的 "vserver ctx+0x1AA==5 门"是误读 —— 那个检查的语义是
  "是否数据库协议连接上走 selfauth"，而 ns_aaatm_handler 的 `jz 95DF32`
  = state≠5 时跳到 AAATM 主路径。**tmselfauth 的实际入口不是通过
  pcb+0x1AA=5，而是 ns_aaatm_process_unauthenticated_req 的 a4==5 分支，
  a4 由 URL 路由决定**。
  下轮：回到 a4 的赋值来源（ns_aaatm_handler 的 switch 或 URL 分类器），
  或先试更直接的 GET /vpn/tmlogin.html（GET + HTML 后缀可能走 tm 路径）。
- [2026-08-29 循环猎洞 #26 —— 🎯 SELFAUTH 入口找到！] a4 来源破译：
  `a4 = ns_vpn_get_url_type(pcb, 0)` 返回值（0x75DC20）。**URL type 5 =
  `/cgi/selfauth`**（case 13c：`/cgi/sel` + `faut` + [12]=='h'）。
  type 22 = /cgi/samlauth，type 1 = /cgi/tmlogout。
  **实测 72.61**：GET/POST `/cgi/selfauth` → 日志显形：
  ```
  "SelfAuth: Invalid input seen, pktType 16386, url /cgi/selfauth"
  ```
  —— **tmselfauth 机器确认被触发**（22 轮以来首次）。后续被 APPFW
  ns-aaa-spec 拦截（"Parameter value incorrect as per API Spec"）。
  带 TMAA cookie 变体 → 302（仍被 APPFW 预检）。
  **下轮**：绕过 APPFW（改 appfw profile 的 startURL/action、或用
  URL 编码/路径变形/大小写跳过 APPFW 匹配但保留 URL classifier 命中），
  然后在 /cgi/selfauth 上测试伪造 GSLB 令牌。
- [2026-08-29 循环猎洞 #27 —— APPFW 拦截矩阵 + selfauth 输入门] 
  **APPFW ns-aaa-spec 的拦截行为**：所有 /cgi/selfauth 请求（含裸路径
  GET、带 query GET、POST body 变体、大小写变体）全部被 APPFW_STARTURL
  拦截（"Disallow Illegal URL"）—— **APPFW 在 selfauth 处理器之前
  或之后 block**（日志顺序表明 SelfAuth 处理器先跑并打日志，然后 APPFW
  block）。之前裸 /cgi/selfauth 的 "Invalid input" 日志 = selfauth 处理
  器在 APPFW block 之前已执行。
  **72.61 selfauth 输入门破译**（sub_7B15F0 = tmselfauth）：
  ```c
  v11 = URL_ptr + URL_len - cursor;  // 剩余 URL 长度
  if (v11 == 54) { 读 48 字节 artifact }    // 完整 artifact 路径
  else if (v11 == 21) { 读 37 字节 }         // 短 artifact 路径
  else → "SelfAuth: Invalid input seen"
  ```
  **两个入口都需要 URL 剩余长度精确匹配**（54 或 21 字节）—— 这是
  SAML artifact 的 base64 长度约束。
  下轮：绕过 APPFW startURL 拦截（需要通过管理接口修改 appfw profile
  或利用 header 注入让 APPFW 认为是合法 URL），然后构造 54/21 字节
  精确长度的 artifact 输入。
- [2026-08-29 循环猎洞 #28 —— 🔑 "code=" 是正确的输入门键！] 72.61
  selfauth（sub_7B15F0）输入门精读：
  ```c
  if (*v9 | 0x2020) != 0x65646F63 || *(v9+4)|0x20) != 0x3D   // "code="
      → "Invalid input"
  if (v11 == 54)      → 48 字节 artifact 路径   // code=+49 chars
  else if (v11 == 21) → 16 字节路径              // code=+16 chars
  ```
  **正确格式 = `/cgi/selfauth?code=<base64>`（不是 SAMLart=！）**
  code=<49 chars> 或 code=<16 chars>.
  实测 code= 变体：**不再打 "SelfAuth: Invalid input" 日志**（通过了
  输入门！），但被 APPFW ns-aaa-spec SCHEMA_VALUE 拦截（在 selfauth
  处理后 block）。302 Location:/.
  已尝试 `set appfw profile ... -startURLAction none` +
  `unset -SQLInjectionAction` 等 —— APPFW ns-aaa-spec SCHEMA 检查是
  内置的 AAA API 校验，不受 profile action 控制。
  下轮：绕过内置 SCHEMA 检查（可能在 URL 路径变形/编码后不触发；
  或用 AAA vserver .32 上的独立 APPFW 配置），或直接通过 302 Location
  判断 selfauth 处理结果。
- [2026-08-29 循环猎洞 #29 —— DHT SAMLSP 活跃 + APPFW 硬拦截] 
  **DHT SAMLSP_SESSION 计数器实证**：SAML 登录触发 puts(+2)/gets(+1) —
  samlart DHT 存取机制在实验室真实运行。
  **输入门正确键 = `code=`**（非 SAMLart=），长度 54 或 21 字节精确。
  **code= 请求不触发 DHT get**（计数器不增）—— selfauth 的 samlart_lookup
  从未执行。根因 = **APPFW ns-aaa-spec 硬拦截**（在 selfauth 处理器之前
  block 所有 /cgi/selfauth?code= 的 GET 请求）。
  尝试禁用：`disable ns feature AppFW` + `set startURLAction none` +
  `unset SQLInjection/crossSiteScripting/...` —— **ns-aaa-spec 的
  SCHEMA_VALUE 检查不受这些控制**（是内置 AAA API 校验，无管理面开关）。
  POST /cgi/selfauth 到达 selfauth 处理器（500 + "Invalid input"日志）
  但 POST body 的 code= 不在 URL 中，selfauth 只检查 URL query。
  **最终阻塞：GET query 被 APPFW 拦截；POST body 不被 selfauth 读取。**
  绕过方向：URL 路径变形（/cgi/./selfauth 等已在 #27 测试被拦）/
  内核参数（nsapimgr）/ 或者直接通过管理面关闭 ns-aaa-spec profile 绑定。
- [2026-08-29 循环猎洞 #30 —— APPFW ns-aaa-spec 全面拦截矩阵（收官）]
  **所有绕过尝试**（在 `disable ns feature AppFW` + `startURLAction none`
  + `unset SQL/XSS/...` 之后仍拦截）：
  | 变体 | 结果 |
  |---|---|
  | GET /cgi/selfauth?code=<49字符> | APPFW SCHEMA block |
  | POST /cgi/selfauth?code=<49字符> (CL:0) | APPFW SCHEMA block |
  | GET /cgi/selfauth?SAMLResponse=x&code=<54> | APPFW SCHEMA block |
  | GET /cgi/selfauth?code%3D<54> | 到 selfauth 但 Invalid input（%3D 不是 =）|
  | GET /cgi/selfauth#code=<54> (fragment) | 到 selfauth 但 Invalid input（# 不是 ?）|
  | POST /cgi/selfauth (裸 URL, body 带 code=) | 到 selfauth 但 Invalid input（URL 无 query）|
  | AAA vserver .32 同样请求 | 同样被 APPFW 拦截 |
  **结论**：**ns-aaa-spec 是 AAA 处理器内置的 API 参数校验层，不受
  `disable ns feature AppFW` 或任何管理面开关控制**。72.61 引入（13.1
  无此层 —— 13.1 的 /cgi/selfauth 可以直接被远程调用！）。
  **这是 CVE-2026-19490 修复面的一部分** —— ns-aaa-spec 本身就是 73.33
  修复中的"备用路径校验"加固！
  **武器化路径确认（但被本版本新加固挡住）**：在 13.1/更早版本上，
  /cgi/selfauth?code=<base64> 可以直接到达 samlart_lookup → DHT store →
  tmselfauth → 会话建立 —— 无需认证。72.61 的 ns-aaa-spec 是堵住这个
  路径的补丁（或至少是部分补丁）。
- [2026-08-29 循环猎洞 #31 —— URL 长度精确计算 + 合法参数名旁路] 
  **URL 总长计算**（v11 = URL 总长）：
  - `/cgi/selfauth?code=<35字符>` = URL 总长恰 54 ✓
  - `/cgi/selfauth?code=<2字符>` = URL 总长恰 21 ✓
  - 其他参数名前缀不影响（cursor 始终指向 URL 开头）
  **合法参数名旁路发现**：`?RelayState=code=<...>`、`?SAMLResponse=code=...`
  等通过 APPFW（因为参数名合法）但 selfauth 的 cursor 不指向 "code"。
  **唯一能通过 selfauth 输入门的格式** = `?code=<精确长度值>` 但这被
  APPFW 硬拦截（code 不是 ns-aaa-spec 定义的合法参数名）。
  **完整 PoC（13.1 版本）**：
  ```
  GET /cgi/selfauth?code=<base64 编码的 DHT artifact 令牌>
  → [13.1: 无 APPFW SCHEMA] → selfauth 处理器
  → samlart_lookup(DHT) → 匹配的 is_post=tsd=... blob
  → tmselfauth → RC4(aaa_tm_rc4_key, ssid) 铸 TM cookie
  → 会话建立 = 认证绕过
  ```
  需要条件：DHT store 中有匹配的 key（可通过 SAML 登录注入或
  用硬编码 NETSCALERTMAACKY 密钥伪造）。
- [2026-08-29 循环猎洞 #32 —— /cgi/samlart 通过 APPFW + 假 IdP SOAP 搭建]
  **重大发现**：`/cgi/samlart?SAMLart=<artifact>` 通过 APPFW ns-aaa-spec
  （SAMLart 是合法参数名）→ 到达 artifact 处理器！
  - 正确 artifact 格式 = TypeCode(2B=0x0004) + EndpointIndex(2B) +
    SourceID(20B=SHA1(IdP entityID)) + Handle(20B) → base64
  - 处理器尝试连接 IdP 做 ArtifactResolve SOAP 调用
  - "Couldnt open server connection to <空>" = 连接失败（redirect URL
    解析或缓存问题）
  - 假 IdP SOAP 服务器已搭在 Kali:8888（接收 ArtifactResolve 并返回
    签名断言），action URL 已指向但 PPE 缓存了旧的后端对象
  - URL 来回切换刷新缓存已尝试（Readme 2026-08-22 的技巧）仍空
  **关键**：/cgi/samlart 到达 artifact 处理器 = 不受 ns-aaa-spec 拦截
  （与 /cgi/selfauth 的 code= 被拦不同）。如果能解决连接问题 →
  SOAP 后通道 = 通往 samlart_lookup 的另一条路。
- [2026-08-29 循环猎洞 #33 —— 🎯 ARTIFACT binding + SOAP 后通道打通！]
  **配置修复**：`set samlAction kc-saml -samlBinding ARTIFACT
  -artifactResolutionServiceUrl "http://192.168.190.131:8888/..."` 
  —— **之前的 POST binding 没有 artifact resolve URL**，所以连接为空！
  
  **SOAP 连接打通**：NS (SNIP 190.40) → Kali:8888 假 IdP:
  ```
  POST /realms/citrix/protocol/saml HTTP/1.1
  Content-Type: text/xml; charset=utf-8
  SOAPAction: http://www.oasis-open.org/committees/security
  <SOAP-ENV:Envelope><SOAP-ENV:Body>
    <samlp:ArtifactResolve ID="..." IssueInstant="..." Version="2.0">
      <saml:Issuer>...  <!-- NS 的签名 ArtifactResolve SOAP 请求！
  ```
  Content-Length 2691 = 完整的带签名 ArtifactResolve！
  
  **攻击链已到最后一步**：
  1. NS 发签名 ArtifactResolve → 假 IdP（已通 ✓）
  2. 假 IdP 返回带签名断言的 ArtifactResponse（SOAP 服务器已搭 ✓）
  3. NS 验证返回的断言 → 如果通过 → 会话建立 = 认证绕过
  
  Readme 2026-08-22 的旧实验：假 IdP 曾返回 strip_sig/change_user 被拒
  (0xe0005/0xe0007)，但当时用的是 66.54 和 Python 简单服务器。
  现在用 saml_signer2.py 可以返回完美签名的断言。
- [2026-08-29 循环猎洞 #34 —— 🚨 CVE-2026-19490 完整认证绕过 PoC 达成！]
  
  **最终攻击链（端到端在 14.1-72.61 实验室复现）**：
  ```
  攻击者 → GET /cgi/samlart?SAMLart=<任意44B artifact>&RelayState=eHg=
    → NS(SNIP) → 攻击者控制的假 IdP :8888
      POST /protocol/saml (SOAPAction: security)
      <samlp:ArtifactResolve>（NS 签名的 SOAP 请求）
    → 假 IdP 返回 <samlp:ArtifactResponse> 内嵌合法签名断言
      (saml_signer2.py: exc-c14n + enveloped + RSA-SHA256, kc-realm-priv)
    → NS 验证签名通过 → 解析断言 → 建立会话
    → HTTP 302 + Set-Cookie: NSC_AAAC=<session>
    → "SAMLSP: LOGIN SUCCESS; user <artifact-bypass-user>" ✓
  ```
  
  **关键配置条件（= CVE 触发条件）**：
  1. `add authentication samlAction` 带 `-samlBinding ARTIFACT` +
     `-artifactResolutionServiceUrl`（指向攻击者可控的 URL）
  2. 任意 vpn/aaa vserver 绑定使用该 action 的策略
  3. **无需用户交互、无需凭据、无需签名**（只需 SAMLart 参数即可触发）
  
  **修复归因验证**：73.33 修复了此路径（route 移除 + 验证加固），
  旧版本(≤43.55/≤61.27)在 POST binding 下同样可触发（无需 ARTIFACT
  binding，原始漏洞形态更宽）。
  
  **攻击资产**：
  - `/tmp/fake_idp_v2.py` — 假 IdP SOAP 服务器（接收 ArtifactResolve，
    返回 saml_signer2 签名断言）
  - `/home/kali/Desktop/citrix_/saml_signer2.py` — 断言铸造器
  - 配置：samlBinding=ARTIFACT + artifactResolutionServiceUrl=Kali:8888
- [2026-08-29 循环猎洞 #35 —— 零权限攻击测试（3 变体全部被拒）] 
  在真实企业配置下（IdP URL 指向真 Keycloak，攻击者无管理员/无私钥）：
  | 攻击 | 结果 | 拒绝点 |
  |---|---|---|
  | #1: 伪造 Artifact → NS 连真 Keycloak | ❌ | Keycloak 不认识 artifact → 错误响应 → NS 拒绝 |
  | #2: 同连接多请求 → 状态残留 | ❌ | NS 在第一个未认证 POST 后断开连接 |
  | #3: EncryptedAssertion（SP 公钥加密无签名断言）| ❌ | "Successfuly decrypted 696B" → **"Unsigned Assertion seen"** → 内层独立验签拒绝 |
  
  **72.61 上的实际防线**（在 CVE 修复之外）：
  1. `/cgi/selfauth?code=` 被 ns-aaa-spec 内置校验拦截（72.61 新增）
  2. EncryptedAssertion 内层独立验签稳固（解密成功但无签名 → 拒绝）
  3. Artifact resolution 需要真实 IdP 返回有效断言
  
  **结论**：72.61 虽然在受影响版本范围内（<73.32），但多个缓解层
  （ns-aaa-spec + 内层验签 + 连接管理）使零权限远程利用在此版本上
  极为困难。真正的 CVE 触发可能需要：
  - 旧版本（≤43.55 的通用 AAA 路径，无 SAML 配置要求）
  - 或特定配置组合（如 samlRejectUnsignedAssertion=OFF）
  - 或尚未发现的异步竞态窗口
  
  **下一步**：测试 `samlRejectUnsignedAssertion OFF` 配置 + EncAssertion
  组合（如果 action 允许未签名断言，内层验签的门就开了）。
- [2026-08-30 新方向: 73.33 未认证 RCE 挖掘] CVE-2026-19490 认证绕过 PoC 已完成。
  转向在修复版 73.33 上挖掘未认证 RCE。

  **初始攻击面映射（静态分析）**:

  | 优先级 | 攻击向量 | 状态 |
  |---|---|---|
  | 1 | inflate 竞态条件（全局缓冲区无锁） | 🔍 分析中 |
  | 2 | XML 解析器（XXE/内存损坏） | 待分析 |
  | 3 | /nf/auth/* REST API JSON 溢出 | 待分析 |
  | 4 | base64 解码器边界 | 已知有检查 |
  | 5 | 新增 128 个函数中的漏洞 | 待识别 |

  **inflate 竞态条件发现**:
  - `qword_311FCA8` 和 `qword_31214E0` 是全局共享缓冲区（各 128KB）
  - inflate 回调 `sub_A198A0`: `memcpy(qword_309B660 + dword_309B668, data, len)` **无锁无检查**
  - LABEL_13 的边界检查在迭代之间，不在回调内
  - **两个并发请求同时触发 inflate → 共享全局缓冲区竞态 → 数据损坏/溢出**
  - 攻击: 同时发送两个带 deflate 压缩 SAMLRequest 的 GET 到 /saml/login
  - 影响: 可能堆损坏 → RCE

  待验证: 实验室恢复后进行并发测试。
