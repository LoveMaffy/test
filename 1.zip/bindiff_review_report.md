# BinDiff 重审报告 — CVE-2026-19490 (CWE-288) 修复定位

**日期**: 2026-08-28（会话续）  
**数据**: bindiff.txt = BinDiff 14.1-72.61(漏洞,primary) ↔ 14.1-73.33(修复,secondary)  
**设备**: 实验室 192.168.190.31 已运行 72.61（与 primary 同一二进制）

## 0. 执行摘要

- 对 bindiff.txt 的 **740 个变更函数做了全量 triage**（此前仅审过 ~10 个）
- 本轮新引入 **flags 维度**：发现 41 个 `sim=1.00 但 flags≠'-------'` 的函数与 84 个
  `-I-----`（仅指令级差异、结构度量完全相同）的外科手术式修改 —— 此前按 sim<1.0 过滤会漏掉这类形态
- 确认 **PI 表达式引擎（136 函数）为最大变更簇 = 库刷新**，非安全
- 深挖完成 20 个 AAA 相关配对：**1 个 LOW-MEDIUM 级 CWE-288 候选**（AAAD advance-auth-policy
  单行确定性修复）+ RADIUS 三点"先验证后写入"重排 + 其余为特性/ABI 平移/加固
- **新发现三个高价值表面**（URL 分类器端点集变化 / SAML SLO 解析器 / ns_aaa_vpn_handle_response），
  使此前"nsppe 内无 CWE-288 修复"的结论降级为**待定**
- 残留盲区不变：73.33 侧 process_data 尾部 184 指令 + 固件其他二进制

## 1. 方法论

### 1.1 队列构建（按 flags × 相似度）
| 队列 | 数量 | 特征 |
|---|---|---|
| flagged100 | 41 | sim=1.00 且 flags≠'-------'（结构等价但指令级有差异）|
| I_only | 84 | flags='-I-----'：仅指令差异，块/边/指令数完全相同 = 常量/寄存器级修改 |
| b95_100 | 277 | 0.95≤sim<1.00 —— **此前从未系统审查的带** |
| b90_95 | 57 | 0.90≤sim<0.95 |
| lt90 | 281 | sim<0.90（含 0.00 垃圾匹配）|
| deleted / added | 12 / 128 | 单侧独有函数 |

### 1.2 工作流（多 agent 编排）
- **Phase 1 Triage**（21 agent × ~40 函数）：每个函数用字符串指纹/独特常量识别模块，
  做误配检查（C 签名+独特常量交叉验证），I_only 队列强制 C-diff
- **Phase 2 Deep-dive**（≤48）：AAA 相关非伪影候选的完整 C 级 diff + 逐块语义解释
- **Phase 3 Verify**（对抗复核）：默认怀疑，重提取证据、排伪影、排代码生成噪声、66.54 三角验证

### 1.3 度量三元组解码（本轮验证）
第二组三元组 = **指令数**（redirect handler 4227 instr / 19256 字节 = 4.55 B/instr ✓）。
由此确认 process_data 72.61 侧 2997 指令 < 3000 导出上限 = **全量可见**（旧论断成立）。

## 2. Phase 1 结果：740 函数模块分布

| 模块桶 | 全部变更 | AAA 相关非伪影 |
|---|---|---|
| PI 表达式引擎(库刷新) | **136** | 0 |
| nFactor/异步ctx | 82 | 14 |
| SPA/SecureBrowse | 56 | 7 |
| SSL/TLS | 43 | 1 |
| OAuth IdP | 26 | **18** |
| 配置分发器 | 24 | 1 |
| HTTP 核心 | 22 | 1 |
| SAML 核心/IdP | 17 | **10** |
| CVPN | 11 | 2 |
| AAA session | 11 | 1 |
| SIP ALG | 8 | 0 |
| AAAD/登录分发 | 7 | 5 |
| EPA/posture | 5 | 3 |
| RADIUS | 3 | 1 |
| NTLM/Kerberos | 2 | 2 |
| 其他/未分类 | 252 | 4 |

伪影嫌疑（兄弟误配/搬移带）：156 个已隔离。AAA 相关非伪影合计：**70**。

## 3. Phase 2 深挖结果（已完成 20 个）

### 3.1 确定性逻辑修复（CWE-288 候选，按相关度排序）

#### ① 4E9570 → 4E9F90（sim 0.99）— AAAD advance auth policy 【LOW-MEDIUM】
- 位置：登录分发路径（0x4E 带），评级至今最接近 CWE-288 形态
- 变化：`*(_WORD*)(policy+664)` 相关判断重排 —— AAA session-hash 构造的真单行确定性修复
- 深挖 agent 原文："genuine single-line deterministic logic fix on the AAAD advance-auth-policy login path"
- 另含 +1616→+1624 / +3808→+3824 的 struct 平移（新字段插入，特性）

#### ② FE1020 / FE25A0 / FE17B0 RADIUS 簇（0.98-0.99）— 先验证后写入重排
- 新标志字节（offset +182 bit0）协调三点修改：
  - FE1020（请求构造）：写 `a1+181`（server-node ID）后新增 `*(a1+182) |= 1`
  - FE25A0（数据处理器）：读侧从 `if (*(v2+181))` 改为 `if ((*(v2+182)&1))`
  - FE17B0（响应处理）：**72.61 在失败检查之前无条件写 `a1+181`**，73.33 移到验证通过之后
- 语义 = 未验证数据不再落入会话状态（CWE-288 家族的"备用写入路径"关闭，RADIUS 面）
- 附带：异步 ctx 枚举重编号（651→653，非语义）

### 3.2 已排除（特性/重构/ABI 平移）
| 函数 | 变更实质 |
|---|---|
| 7DC0C0 / 7E0460 / 7D1A50 / 78C410 | 新 AAA 配置旋钮（global+5291 默认 7）的序列化传播——同一特性多点落位 |
| AA30D0（nFactor EPA）| session-tag 字符串长度计算修复（u16 字段 BYTE→WORD 拓宽），正确性非绕过 |
| 9E1850（AppFlow reporter）| strlen→精确长度（CWE-125 家族加固）+ 新遥测参数 |
| CD6F50 | 配置 reset 的内存生命周期加固（泄漏/悬挂节点）|
| 11C5D40 / 11D3310（OAuth JWKS）| Connection 头管理 + 未初始化寄存器传参清理 |
| 7F6890 | 哈希桶头节点删除的 OWORD 拷贝重排（代码生成）|

## 4. 新发现的高价值表面（待深挖）

### 4.1 58BF10 → 58C920（0.87）— SAML metadata URL 匹配器变化【KEY】
- 72.61：前缀匹配 `/metadata/samlsp`（16 字符）→ 返回 **35 ('#')**
- 73.33：前缀匹配 `/metadata/samlidp`（17 字符）→ 返回 **36 ('$')**
- 全二进制扫描证明每个二进制**只有一个**此类匹配器（非兄弟误配）；66.54 两者皆无（66.54 后新增特性）
- **直接影响巨型 URL 分类器（0x57D3A0，17976 行，'CEB FQDN found in patset'）处理的
  未认证 AAA 端点集合** —— 正落在 CVE-2026-19490 的 auth-dispatch 表面
- 待办：反编译调用者 0x57D3A0↔0x57DF40，确定 '#'(35) 与 '$'(36) 各自 gate 的处理路径

### 4.2 A2C150 → A2DD00（0.98）— SAML IdP LogoutRequest 解析器（SLO）
- 1220 块大函数，字符串含 'Unsigned Assertion seen, denying the request'、'digest method'、
  'List of Transforms Method exceeds max limit'、'NotOnOrAfter'
- 调用者 0x9EE2F0 / 0xA3C2F0；双版 asm-fallback —— 在深挖队列

### 4.3 522350 → 522D70（0.98）— ns_aaa_vpn_handle_response
- **AAA VPN 登录响应处理点**（FUNC 名自证）；含 'NGS Connector response'、'Set-Cookie'、
  'NSC_BODY=xyz;Path=/;expires=...' —— 登录完成→cookie 签发链 —— 在深挖队列

### 4.4 11B53D0 → 11BBBB0（0.67）— OAuth IdP login 端点解析器
- 72 侧 0x4FD0 字节/5581 行 → 73 侧 7064 行：特性级大增长（新 tags/fields）

## 5. 对既有结论的修正与维持

| 旧结论 | 状态 |
|---|---|
| parse_assertion / nfactor_start_saml / 路由匹配器 / action 反序列化 1.00 未变 | 维持 |
| process_data 仅错误路径重排（72.61 侧全量可见）| 维持（度量解码加固了此论断）|
| SAMLEncoding / AuthnRequest-tag-end 两个 CWE-125 = 加固非主修复 | 维持 |
| SIP ALG ns_sip_parse_uri 重写 = CVE-2026-19489 修复 | 维持 |
| **"nsppe 内无 CWE-288 修复"** | **降级为待定**：4E9570(LOW-MEDIUM) + RADIUS 重排 + 三个新表面 |

## 6. 残留盲区与下一步
1. 工作流 Phase 2 剩余 ~28 个深挖 + Phase 3 对抗复核（进行中）
2. **58BF10 调用者（URL 分类器 0x57D3A0）的 35/36 gate 语义** —— 最高优先级手工跟进
3. 73.33 侧 process_data 尾部 184 指令（需 73.33 完整固件 + objdump）
4. 固件其他二进制（nsnetsvc/nsconfigd/imi）全组件 diff（需完整 73.33 固件包）
5. 实验室行为验证：`/metadata/samlidp` vs `/metadata/samlsp` 端点在 72.61 设备上的实际行为差异

---
*报告由 bindiff-rereview 工作流（21 triage + N deep-dive + 对抗复核 agent）自动收割生成；
原始数据：/tmp/wf_harvest.json、bindiff_review/ 目录各队列 JSON。工作流仍在运行，完成后追加终版裁决。*
## 7. 终版追加（工作流停止前最终收割：705 triage / 37 deep-dive，Phase 3 对抗复核未跑）

最后一批深挖（+17）产出**两个新的同家族 CWE-125 修复**，使该家族在本次修复边界上达到 **4 个**：

### ⑦ A003D0 → A01FB0（IdP 侧 Redirect Binding AuthnRequest 查询解析器）— **jb→jl 符号修复【重要】**
- 3920 指令函数中**唯一**的真实变化：既有的 73 字节边界检查
  `lea rax,[r12+0Dh]; sub rcx,rax; cmp rcx,49h; jb/jl bail` 的条件跳转从 **`jb`（无符号）改为 `jl`（有符号）**
- 语义：72.61 中若解析游标已越过缓冲区末尾（`end - (ptr+0xD)` 下溢为负 → 无符号巨数），
  `jb` **不会**走 bail → 73 字节 URN 字面量比较链从越界指针读取；`jl` 使下溢值正确触发拒绝（0xE0005）
- 这是 SP 侧（A3E200 新增检查）的 **IdP 侧姊妹修复** —— 证明 73.33 对 SAML Redirect Binding
  双侧（SP+IdP）的同一模式做了协同加固
- **潜在影响链**：越界 URN 匹配成功 → IdP 对 AuthnRequest 选择 DEFLATE 路径 → inflate 越界数据 →
  基于其构造签名响应 —— 与"认证绕过"标签存在可构想的桥接

### ⑧ A2C150 → A2DD00（SAML IdP LogoutRequest 解析器/SLO）— 新增 20 字节边界检查
- 20448→20464 字节函数中唯一真实变化：`0xA30E52` 处插入 16 字节
  `remaining = end - ptr; if (remaining < 0x14) bail(0xE0005)`
- 守护对象：`NotOnOrAfter` dateTime 的 20 字节 SSE 拷贝
  （`movups xmm0,[r15]; movups [r12+254h],xmm0; or byte[r12+238h],4`）

### CWE-125 家族汇总（本修复边界，全部在 SAML 预认证解析）
| # | 函数对 | 修复内容 |
|---|---|---|
| 1 | A3E200→A3FE00（SP Redirect Binding）| 新增 73 字节 SAMLEncoding URN 匹配边界 |
| 2 | A34D90→A36950（IdP AuthnRequest 解析器）| 新增 memchr('>') tag-end 校验 |
| 3 | **A003D0→A01FB0（IdP Redirect Binding 查询解析）** | **jb→jl 符号修复（游标越末尾下溢绕过）** |
| 4 | A2C150→A2DD00（IdP SLO LogoutRequest）| 新增 20 字节 NotOnOrAfter 拷贝边界 |

其余终批深挖：EPA v2 negotiate 新增会话状态字节条件（LOW）、11EBDB0 jumptable 收缩+新检查（LOW）、
大量泄漏修复/枚举重编号/布局平移（全部 LOW/NONE）。

### 终版裁决
1. **73.33 对 SAML 解析面做了系统性 CWE-125 清扫（4 处，SP+IdP 双侧）** —— 与公告的
   "SAML/AAA vserver 触发 + 认证处理路径"高度吻合；其中 A003D0 的符号修复是唯一一个
   "已存在检查被绕过"形态（无符号下溢），其影响链可桥接到认证语义
2. **4E9570（AAAD advance-auth-policy 单行确定性修复）保持 LOW-MEDIUM 的 CWE-288 候选地位**，
   未经对抗复核（Phase 3 未跑）
3. RADIUS 三点"先验证后写入"重排 = 备用写入路径关闭（CWE-288 家族边缘）
4. 全部其余深挖结果归为特性/ABI 平移/泄漏加固/枚举重编号
5. **行动建议**：(a) 72.61 设备上对 `/metadata/samlsp` vs `samlidp` 端点集变化做行为对比；
   (b) A003D0 的 jb→jl 绕过 —— 构造"游标越末尾"前置条件（超长 AuthnRequest 查询参数截断）——
   值得在实验室直接复现；(c) 拿 73.33 完整固件补 process_data 尾部 184 指令盲区

*原始数据：/tmp/wf_harvest_final.json（705 triage + 37 deep）；bindiff_review/ 队列 JSON。*
